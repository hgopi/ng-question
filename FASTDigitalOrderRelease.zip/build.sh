sh ./npm-install.sh
if [ $? -ne 0 ]; then
  echo "Error in npm or bower install"
  exit 1
fi

npm run build
if [ $? -ne 0 ]; then
  echo "Error in running grunt"
  exit 1
fi

npm run content
if [ $? -ne 0 ]; then
  echo "Error in running npm run build"
  exit 1
fi
