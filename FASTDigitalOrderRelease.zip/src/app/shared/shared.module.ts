import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import * as fromComponents from './components';
import * as fromServices from './services';
import * as fromDirectives from './directives/';
import { httpInterceptorProviders } from './http-interceptors';
import { AppState } from './state/AppState';
import { ContentsResolver } from './resolver/contents.resolver';
import { RouteGuard } from './resolver/route-guard.service';
import * as fromPipes from './pipes';
import { CurrencyPipe } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

const COMPONENTS = [
    fromComponents.LoaderComponent,
    fromComponents.AlertComponent,
    fromComponents.ModalComponent,
    fromComponents.PaymentsListComponent,
    fromComponents.RxListComponent,
    fromComponents.ShippingAddressComponent,
    fromComponents.AccountBalanceComponent,
    fromDirectives.DateInputDirective,
    fromDirectives.SessionTimeoutDirective,
    fromDirectives.CmsSpotDirective,
    fromDirectives.InputPatternDirective,
    fromPipes.CapitalizePipe,
    fromPipes.ExpirationPipe,
    fromPipes.CardTitlePipe,
    fromPipes.ShipDescription
];

@NgModule({
    imports: [
        CommonModule,
        HttpClientModule,
        RouterModule,
        ReactiveFormsModule
    ],
    declarations: COMPONENTS,
    exports: COMPONENTS,
    entryComponents: [
        fromComponents.ModalComponent
    ],
    providers: httpInterceptorProviders
})
export class SharedModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: SharedModule,
            providers: [
                fromComponents.LoaderService,
                fromComponents.ModalService,
                fromServices.BackEndService,
                fromServices.TealiumUtagService,
                fromServices.EccrService,
                ContentsResolver,
                AppState,
                fromPipes.CapitalizePipe,
                fromPipes.ExpirationPipe,
                fromPipes.CardTitlePipe,
                fromPipes.ShipDescription,
                CurrencyPipe,
                RouteGuard
            ]
        };
    }
}
