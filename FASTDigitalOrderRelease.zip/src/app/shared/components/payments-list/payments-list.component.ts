import { Component, OnInit, Input, Output, EventEmitter, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { ROUTE_PATHS, ALERT_TYPE, STATES, CARD_TYPE } from '../../enum';
import { isEmpty, find, findIndex } from 'lodash-es';
import { AlertData } from '../index';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AppState } from '../../state/AppState';
import { Subscription } from 'rxjs/Subscription';
import { CapitalizePipe } from '../../pipes/capitalize.pipe';

@Component({
  selector: 'payments-list',
  templateUrl: './payments-list.component.html',
  styleUrls: ['./payments-list.component.scss']
})
export class PaymentsListComponent implements OnInit, OnDestroy {

  banner: any;
  paymentList$: Subscription;
  paymentsForm: FormGroup;
  bannerMsgAlert = <AlertData>{
    type: ALERT_TYPE.NONE,
    data: { title: '', description: '' }
  };

  paymentList: any;
  @Output() onEditPayment = new EventEmitter<string>();

  constructor(
    private _router: Router,
    private _appState: AppState,
    private _fb: FormBuilder,
    private _capitalize: CapitalizePipe) {
      this.paymentList$ = this._appState.select(STATES.PAYMENTS_LIST).subscribe((list) => {
        this.paymentList = list;
        if (this.paymentList && this.paymentList.bank) {
          this.paymentList.bank.forEach((bankAcc) => {
            bankAcc.displayName = this._capitalize.transform(bankAcc.AccountName.slice(0, -7));
          });
        }
      });
      this.banner = this._appState.getBannerDetails();
      if (this.banner && this.banner.bannerMsg && (this.banner.bannerMsg.length > 0) && this.banner.bannerMsg.indexOf('&') > -1) {
        this.bannerMsgAlert = <AlertData>{
          type: ALERT_TYPE.WARNING,
          data: {
            title: this.formattedAlertHead(this.banner.bannerMsg.split('&')[0]),
            description: this.banner.bannerMsg.split('&')[1],
          }
        };
      }
      if (this._appState.lastFocused) {
        setTimeout(() => {
          try {
            document.getElementById(this._appState.lastFocused).focus();
            this._appState.lastFocused = null;
          } catch (e) {}
        }, 0);
      }
  }

  ngOnInit() {
    this.paymentsForm = this._fb.group({
      selectPayment: ['', Validators.required]
    });
    const selectedPayment = this._appState.getSelectedPayment();
    if (selectedPayment) {
      const key = selectedPayment.ElectronicPaymentAccountType === 'CC' ? 'card' : 'bank';
      const index = findIndex(this.paymentList[key],
        (pay: any) => pay.ElectronicPaymentAccountID === selectedPayment.ElectronicPaymentAccountID);
      this.paymentsForm.setValue({
        selectPayment: key + '_' + index
      });
    }
  }

  editCard(type, index, event) {
    this._appState.lastFocused = event.target ? event.target.id : null;
    this.onEditPayment.emit('edit');
    this._appState.setEditPayment({ type: type, index: index });
    this._router.navigate([ ROUTE_PATHS.EDIT_CARD ], {queryParamsHandling: 'merge'});
  }

  addCard(event) {
    this._appState.lastFocused = event.target ? event.target.id : null;
    this.onEditPayment.emit('add');
    this._appState.setEditPayment(null);
    this._router.navigate([ ROUTE_PATHS.EDIT_CARD ], {queryParamsHandling: 'merge'});
  }

  updateSelectedPayment(type, i) {
    this._appState.setSelectedPayment(type, i);
  }

  getCardTitle(card) {
    return card.AccountName;
  }

  addAccount(event) {
    this._appState.lastFocused = event.target ? event.target.id : null;
    this.onEditPayment.emit('edit');
    this._router.navigate([ ROUTE_PATHS.EDIT_BANK_ACC ], {queryParamsHandling: 'merge'});
  }

  formattedAlertHead(header) {
    if (header.indexOf('<$##.##>') > -1) {
      header = header.replace('<$##.##>', '$' + this.banner.orderBalanceAmount || '');
    }
    if (header.indexOf('<$####>') > -1) {
      header = header.replace('<$####>', '$' + this.banner.orderBalanceAmount || '');
    }
    if (header.indexOf('<####>') > -1) {
      header = header.replace('<####>', ('0000' + this.banner.paymentAccount.creditCardNumber).slice(-4));
    }
    if (header.indexOf('<card type>') > -1) {
      header = header.replace('<card type>', this._capitalize.transform(CARD_TYPE[this.banner.paymentAccount.paymentTypeCode] || ''));
    }
    return header;
  }

  ngOnDestroy() {
    this.paymentList$.unsubscribe();
  }

}
