import { Injectable, Inject } from '@angular/core';
import { ModalComponent } from './modal.component';
import { BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { TealiumUtagService } from '../../services/utag.service';
import { Tagging } from '../../config/tagging-constants';

export enum MODAL_TYPE {
  ORDER_CANCEL,
  SESSION_TIMEOUT
}

@Injectable()
export class ModalService {

  defaultConfig: ModalOptions = {
    keyboard: false,
    backdrop: 'static',
    animated: false
  };

  constructor(private _modalService: BsModalService, private _analytics: TealiumUtagService) {
  }

  open(config) {
    const modalRef = this._modalService.show(ModalComponent, Object.assign({}, this.defaultConfig, { initialState: config.data }));
    if (config.type === MODAL_TYPE.ORDER_CANCEL) {
      this._analytics.view({
        Page_Name: Tagging.CancelOrderConfirmation,
        Page_Category: Tagging.OnHoldPageName
      });
    }

    if (config.hideCloseBtn) {
      modalRef.content.hideCloseBtn = config.hideCloseBtn;
    }

    modalRef.content.primaryAction.subscribe((data) => {
      if (config.type === MODAL_TYPE.ORDER_CANCEL) {
        this._analytics.link({
          onhold_submit: Tagging.CancelOnHoldSubmit,
          link_name: Tagging.CancelOnHoldLink
        });
      }
      if (config.success && typeof config.success === 'function') {
        config.success(data);
      }
    });

    modalRef.content.secondaryAction.subscribe((data) => {
      if (config.cancel && typeof config.cancel === 'function') {
        config.cancel(data);
        if (config.returnFocusTo) {
          setTimeout(() => {
            try {
              document.querySelector(config.returnFocusTo).focus();
            } catch (e) {}
          }, 0);
        }
      }
    });

    return modalRef;
  }

}
