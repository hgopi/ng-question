export interface ModalData {
    modalTitle?: String;
    modalBody: String;
    positiveButton?: String;
    negativeButton?: String;
}
