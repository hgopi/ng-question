import { Component, Input, Output, EventEmitter, AfterViewInit, Renderer2, ElementRef } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { Utils } from '../../utils';


@Component({
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss']
})
export class ModalComponent implements AfterViewInit {
  title: string;
  body: string;
  primaryButton: string;
  secondaryButton: string;
  @Output() primaryAction = new EventEmitter();
  @Output() secondaryAction = new EventEmitter();
  hideCloseBtn = false;

  constructor(
    public bsModalRef: BsModalRef,
    private _renderer: Renderer2,
    private _elementRef: ElementRef
  ) {
  }

  success(data = null) {
    this.primaryAction.emit(data);
    this.bsModalRef.hide();
  }

  close(data = null) {
    this.secondaryAction.emit(data);
    this.bsModalRef.hide();
  }

  ngAfterViewInit() {
    this._renderer.setAttribute(document.querySelector('.modal'), 'aria-labeledby', 'modalTitle');
    if (Utils.isInIframe()) {
      setTimeout(() => {
        const top = Utils.positionModalDialog();
        this._renderer.setStyle(document.querySelector('.modal'), 'margin-top', top + 'px');
      }, 0);
    }
    setTimeout(() => {
      const modalParent = this._elementRef.nativeElement.parentElement;
      const focusables = modalParent.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
      try {
        focusables[0].focus();
        this._renderer.listen(modalParent, 'keydown', (e) => {
          const keycode = e.keycode || e.which;
          if (keycode === 9) {
            const elementFocused = e.target;
            if (!e.shiftKey && elementFocused === focusables[focusables.length - 1]) {
              e.preventDefault();
              focusables[0].focus();
            }
            if (e.shiftKey && elementFocused === focusables[0]) {
              e.preventDefault();
              focusables[focusables.length - 1].focus();
            }
          }
        });
      }  catch (e) {}
    }, 100);
  }


}
