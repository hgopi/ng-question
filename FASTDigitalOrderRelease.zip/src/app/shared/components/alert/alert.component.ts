import { Component, OnInit, Input, ElementRef, ViewChild, OnChanges, SimpleChanges } from '@angular/core';
import { isArray } from 'lodash-es';
import { ALERT_TYPE } from '../../enum';
import { Utils } from '../../utils';

@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.scss']
})
export class AlertComponent implements OnInit, OnChanges {
  
  @Input() config: any;
  @ViewChild('alert') alert: ElementRef;

  constructor() { }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.config && !changes.config.firstChange) {
      Utils.scrollToTop();
    }
    if (changes.config.currentValue && changes.config.currentValue.type === ALERT_TYPE.ERROR) {
      setTimeout(() => {
        this.alert.nativeElement.focus();
      }, 0);
    }
  }

  get link() {
    if (this.config.data.link) {
      return isArray(this.config.data.link) ? this.config.data.link : [this.config.data.link];
    }
  }

  get isVisible() {
    return this.config.type !== ALERT_TYPE.NONE;
  }

  get alertIfError() {
    return (this.config.type === ALERT_TYPE.ERROR ? 'alert' : null) ;
  }

  get label() {
    if (this.config.data.label) {
      return isArray(this.config.data.label) ? this.config.data.label : [this.config.data.label];
    }
  }

  goto(id) {
    try {
      const element = document.querySelector('#' + id) as HTMLElement;
      element.focus();
    } catch (e) {}
  }

}

export interface AlertLabel {
  for: string;
  text: string;
}

export interface AlertLink {
  text: string;
  callback: (data: any) => void;
}

export interface AlertData {
  type: string;
  data: {
    title: string,
    description?: string | Array<string>,
    link?: AlertLink |AlertLink[],
    label?: AlertLabel | AlertLabel[]
  };
}
