import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { Contents } from '../../config/content';
import { AppState } from '../../state/AppState';
import { STATES } from '../../enum';
import { AccountBalance } from '../../state/iState';

@Component({
  selector: 'account-balance',
  templateUrl: './account-balance.component.html',
  styleUrls: ['./account-balance.component.scss']
})
export class AccountBalanceComponent implements OnInit, OnDestroy {

  @Input() headerLevel = 'h3';

  accountBalance: AccountBalance;
  accountBalance$: Subscription;
  content = Contents.accountBalance;

  constructor(private _appState: AppState) {

    this.accountBalance$ = this._appState.select<AccountBalance>(STATES.ACCOUNT_BALANCE).subscribe((account) => {
      this.accountBalance = account;
      this.calculateTotal();
    });

  }

  ngOnInit() {

  }

  calculateTotal() {
    if (this.accountBalance.isMedD) {
      this.accountBalance.totalDue = this.accountBalance.estimatedCost + this.accountBalance.shippingCost;
    } else {
      this.accountBalance.totalDue = this.accountBalance.estimatedCost + this.accountBalance.shippingCost + this.accountBalance.outstandingBalance;
    }
  }

  ngOnDestroy(): void {
    this.accountBalance$.unsubscribe();
  }

}
