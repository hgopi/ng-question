import { Component, Input, OnDestroy } from '@angular/core';
import { AppState } from '../../state/AppState';
import { OrderDetails } from '../../state/iState';
import { STATES } from '../../enum';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'shipping-address',
  templateUrl: './shipping-address.component.html',
  styleUrls: ['./shipping-address.component.scss']
})
export class ShippingAddressComponent implements OnDestroy {

  @Input() headerLevel = 'h3';

  orderDetails$: Subscription;
  address: any = {};

  constructor(private _appState: AppState) {
    this.orderDetails$ = this._appState.select<OrderDetails>(STATES.ORDER_DETAILS).subscribe((details) => {
      this.address = details.shippingAddress;
    });
  }

  ngOnDestroy() {
    this.orderDetails$.unsubscribe();
  }

}
