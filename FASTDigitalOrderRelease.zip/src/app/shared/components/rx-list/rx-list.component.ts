import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'rx-list',
  templateUrl: './rx-list.component.html',
  styleUrls: ['./rx-list.component.scss']
})
export class RxListComponent implements OnInit {

  @Input() rxList: any;
  @Input() showRxAndSupply = true;
  @Input() sectionHeader = 'long';
  @Input() useSectionTag;
  @Input() isEditable = false;
  @Input() headerLevel = 'h3';
  @Input() isIndefiniteHold = false;

  @Output() editCallback = new EventEmitter<boolean>();

  constructor() { }

  ngOnInit() {
  }

}
