import { Directive, HostListener, OnDestroy } from '@angular/core';
import { ModalService, MODAL_TYPE } from '../components/index';
import { Contents } from '../config/content';
import { BackEndService } from '../services/back-end.service';
import { environment } from '../../../environments/environment';
import 'rxjs/add/operator/finally';

@Directive({
  selector: '[sessionTimeout]'
})
export class SessionTimeoutDirective implements OnDestroy {
  sessionLastTimeout: any;
  redirectUrl: string;
  idleInterval: any;
  idleTime = 0;
  contents = Contents.modal.sessionTimeout;

  constructor(private _modal: ModalService, private _backEnd: BackEndService) {
    if (this.idleInterval) {
      clearInterval(this.idleInterval);
    }
    this.redirectUrl = this.getRedirectUrl();
    this.initSessionTimeout();
  }

  initSessionTimeout() {
    this.idleInterval = setInterval(() => {
      this.idleTime += 1;
      if (this.idleTime === Contents.sessionTimeoutAlertMins) {
        clearInterval(this.idleInterval);
        const returnFocusTo = document.activeElement as HTMLElement;
        this.sessionLastTimeout = setTimeout(() => {
          this.initExpireToken();
        }, Contents.sessionLastTimeoutMins * 60000); // 2 mins
        this._modal.open({
          type: MODAL_TYPE.SESSION_TIMEOUT,
          data: {
            title: this.contents.title,
            body: this.contents.body,
            primaryButton: this.contents.primaryButton,
            secondaryButton: this.contents.secondaryButton,
          },
          success: () => {
            this._backEnd.refreshToken().subscribe(() => {
              clearTimeout(this.sessionLastTimeout);
              this.idleTime = 0;
              this.initSessionTimeout();
              setTimeout(() => {
                try {
                  returnFocusTo.focus();
                } catch (e) {}
              }, 0);
            }, (error) => {
              console.log(error);
              this.initExpireToken();
            });
          },
          cancel: () => {
            this.initExpireToken();
          },
          hideCloseBtn: true,
          modalOptions: {
            backdrop: 'static',
            keyboard: false
          }
        });
      }
    }, 60000);
  }

  initExpireToken() {
    this._backEnd.expireToken().finally(() => {
      if (window.parent) {
        window.parent.location.href = this.redirectUrl;  
      } else {
        window.location.href = this.redirectUrl;
      }
    }).subscribe((data) => {
      console.log(data);
    });
  }

  @HostListener('mousemove', ['$event'])
  @HostListener('document:keypress', ['$event'])
  clearIdleTime() {
    this.idleTime = 0;
  }

  getRedirectUrl() {
    return `${environment.timeoutURL}GUEST_AUTHENTICATION/?XID=${environment.xid}&wfct=${environment.workFlowContext}&cid=${environment.webTrendsMsgId}&alertType=${environment.alertType}&lpg=${environment.landingPageURL}&dobRequired=true&sessionExpired=true`;
  }

  ngOnDestroy(): void {
    clearInterval(this.idleInterval);
  }

}
