import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
    selector: '[dateInput]',
})
export class DateInputDirective {

    constructor(private el: ElementRef) {}

    @HostListener('input', ['$event'])
    genericEventHandler(event: Event) {
        const iElement = <HTMLInputElement>this.el.nativeElement;
        const iValue   = iElement.value;
        let nextValue = iValue.replace(/[\D]/gi, '');

        if (nextValue.length >= 3 && nextValue.length <= 4) {
            nextValue = nextValue.replace(/(\d{2})(\d{2})?/, '$1/$2');
        } else if (nextValue.length >= 5 && nextValue.length <= 8) {
            nextValue = nextValue.replace(/(\d{2})(\d{2})(\d{4})?/, '$1/$2/$3');
        }

        let cursorIndex = iElement.selectionStart;

        if (nextValue !== iValue) {
            if (/^\d{4}/.test(iValue) && cursorIndex === 4) {
                cursorIndex += 1;
            }
            if (/^\d+\/\d+\/\d+/.test(iValue) && cursorIndex === 5) {
                cursorIndex += 1;
            }
        }
        if (cursorIndex === 3 || cursorIndex === 6) {
            if (cursorIndex > nextValue.length || (iValue.length !== nextValue.length)) {
                cursorIndex += 1;
            }
        }
        this.el.nativeElement.value = nextValue;
        iElement.setSelectionRange(cursorIndex, cursorIndex);
    }
}
