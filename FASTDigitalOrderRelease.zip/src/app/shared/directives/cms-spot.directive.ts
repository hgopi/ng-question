import { ElementRef, Input, Component, OnInit, SecurityContext } from '@angular/core';
import { environment } from '../../../environments/environment';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Component({
    selector: 'cms-spot',
    template: '<ng-content></ng-content>'
})
export class CmsSpotDirective implements OnInit {

    @Input('cms-data') cmsData: string;

    constructor(private element: ElementRef, private _sanitizer: DomSanitizer) {}

    ngOnInit(): void {
        if (this.cmsData && environment.cms && environment.cms[this.cmsData]) {
            setTimeout(() => {
                this.element.nativeElement.innerHTML = this.sanitizeHTML(environment.cms[this.cmsData]);
            }, 0);
        } else {
            return;
        }
    }

    sanitizeHTML(content): SafeHtml  {
        return this._sanitizer.sanitize(SecurityContext.HTML, content);
    }
}
