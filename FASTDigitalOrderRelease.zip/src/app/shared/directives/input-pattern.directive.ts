import { Directive, ElementRef, Input, HostListener } from '@angular/core';

@Directive({
    selector: '[inputPattern]'
})
export class InputPatternDirective {

    @Input() accept: RegExp;

    constructor(private el: ElementRef) {}

    @HostListener('keypress', ['$event'])
    onKeyPress(evt) {
        const value = this.el.nativeElement.value;
        const keyCode = evt.which || evt.keyCode;
        const keyCodeChar = String.fromCharCode ( keyCode );
        
        if ( /[a-zA-Z0-9-_ ]/.test(keyCodeChar) && !keyCodeChar.match ( new RegExp ( this.accept, 'i' ) ) ) {
            evt.preventDefault (  );
            return false;
        } else {
            return true;
        }
    }

}
