import { Injectable } from '@angular/core';
import { flatten, keyBy, groupBy, intersection, each, filter } from 'lodash-es';
import { environment } from '../../../environments/environment';
import { CapitalizePipe } from '../pipes/capitalize.pipe';
import { CurrencyPipe } from '@angular/common';
import { RELEASE_STATUS, ORDER_ALERT_TYPE, CONSENTS, REASON_CODES } from '../enum';
import { ReasonCodes } from '../config/reasonCodes';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { InitialState, State, OrderDetails, PaymentList, iShipMethod, ShippingError } from './iState';
import 'rxjs/add/operator/pluck';
import 'rxjs/add/operator/distinctUntilChanged';
import { Observable } from 'rxjs/Observable';
import { find } from 'lodash';
import { Contents } from '../config/content';
import { Utils } from '../utils';

@Injectable()
export class AppState {

    componentState: any = null;
    private _isSet = false;
    private onHoldReleaseStatus: RELEASE_STATUS;
    private updatedAccountBalance: any = {};
    public subject = InitialState;
    public lastFocused = null;

    constructor(private _capitalize: CapitalizePipe, private _currency: CurrencyPipe) {}

    get isOrderDetailsSet() {
        return this._isSet;
    }

    select<T>(name): Observable<T> {
        return this.subject[name];
    }

    setOrderDetails(order: any) {
        const prescriptions = flatten([order.prescriptionList]);
        this._isSet = true;
        this.subject.orderDetails.next(Object.assign({}, {
            orderNumber: Array.isArray(order.orderNumber) ? order.orderNumber[0] : order.orderNumber,
            rxList: this.findRxList(prescriptions),
            shippingAddress: this.getAddress(order.shippingAddress),
            orderPlaced: order.orderDate,
            orderTimeToRelease: order.ordTimeToRelease,
            shippingCost: order.shippingCost,
            outstandingBalance: order.orderBalanceAmount,
            payAmount: order.payAmount,
            contactEmail: order.contactEmail,
            topLevelMessage: this.getTopLevelMessage(order, prescriptions),
            selectedRx: [],
            shipMethod: order.shipMethod,
            bannerMsg: order.bannerMsg,
            paymentAccount: this.getPaymentAccount(order),
            participantId: order.participantId
        }, this.findReasonCode(prescriptions)));
        this.subject.accountBalance.next(Object.assign({}, this.getAccountBalance(order)));
    }

    getBannerDetails() {
        // if (this.subject.orderDetails.value.reasonCode === CONSENTS.PAYMENT_ONLY) {
            return {
                bannerMsg: this.subject.orderDetails.value.bannerMsg,
                orderBalanceAmount: this.subject.orderDetails.value.outstandingBalance,
                paymentAccount: this.subject.orderDetails.value.paymentAccount
            };
        // }
    }

    setShippingError(error: ShippingError) {
        this.subject.shippingError.next(error);
    }

    setServiceFailed() {
        this.subject.orderDetails.next({
            ...this.subject.orderDetails.value,
            reasonCode: -1
        });
    }

    getPaymentAccount(order) {
        if (order.electronicPaymentAccount && order.electronicPaymentAccount.creditCardNumber) {
            return {
                ...order.electronicPaymentAccount
            };
        }
        return null;
    }

    findReasonCode(prescriptions) {
        // For demo only, no need on prod.
        if (environment.reasonCode) {
            const reasonCode = environment.reasonCode;
            if (reasonCode === '1') {
                return this.filterPrescriptions(prescriptions, ReasonCodes.consentToPay);
            } else if (reasonCode === '2') {
                return this.filterPrescriptions(prescriptions, ReasonCodes.paymentAlert);
            } else if (reasonCode === '3') {
                return this.filterPrescriptions(prescriptions, ReasonCodes.consentShip);
            } else if (reasonCode === '4') {
                return this.filterPrescriptions(prescriptions, ReasonCodes.indefiniteHold);
            } else {
                return this.orderResolved();
            }
        }

        const alertType = environment.alertType || 'paymentHoldAlert';
        const allReasonCodes = Object.keys(keyBy(prescriptions, (prescription) => prescription.reasonCode)).map(Number);
        switch (alertType) {
            case ORDER_ALERT_TYPE.PAYMENT_HOLD:
                return this.onPaymentHoldAlert(prescriptions, allReasonCodes);
            case ORDER_ALERT_TYPE.SHIPMENT_CONSENT_HOLD:
                return this.onShipConsentHoldAlert(prescriptions, allReasonCodes);
            case ORDER_ALERT_TYPE.INDEFINITE_HOLD:
            case ORDER_ALERT_TYPE.PPT_HOLD:
                return this.onIndefiniteHoldAlert(prescriptions, allReasonCodes);
            default:
                break;
        }
    }

    getParticipantId() {
        return this.subject.orderDetails.value.participantId;
    }

    getTopLevelMessage(order, prescriptions) {
        let message = '';
        if (order.multiplePYBCodePresent === 'Y') {
            message = order.orderDefaultPYBDesc || '';
        } else if (order.multiplePYBCodePresent === 'N' && prescriptions.length) {
            const isRxDescFound = prescriptions.filter((prescription) => prescription.rxPaymentProblem &&
              find(prescription.rxPaymentProblem, 'pybLongDesc'));
            const isOrderDescFound = (order.orderPYBCode && order.orderPYBCode !== '' && order.orderPYBCode.length);
            if ((isRxDescFound.length > 1) || ((isRxDescFound.length > 0) && isOrderDescFound)) {
                // multiple PYB Codes - more than 1 at Rx level OR one at Order level plus one or more at Rx level
                message = order.orderDefaultPYBDesc || '';
            } else if ((isRxDescFound.length === 0 ) && isOrderDescFound) {
              // one PYB Code is present for entire order - only one at the Order level and none at Rx level - so show orderPYBLongDesc
              message = order.orderPYBLongDesc;
            } else if ((isRxDescFound.length === 1) && !isOrderDescFound) {
              // one PYB Code is present for entire order - only one at Rx level and none at Order Level - so show Rx Level PYBLongDesc
                // need the pybLongDesc at the Rx Level
              message = isRxDescFound[0].rxPaymentProblem[0].pybLongDesc;
            }
        }
        return message;
    }

    onPaymentHoldAlert(prescriptions, allReasonCodes) {
        if (intersection(allReasonCodes, ReasonCodes.consentToPay.checkWith).length > 0) {
            return this.filterPrescriptions(prescriptions, ReasonCodes.consentToPay);
        } else if (intersection(allReasonCodes, ReasonCodes.paymentAlert.checkWith).length > 0) {
            return this.filterPrescriptions(prescriptions, ReasonCodes.paymentAlert);
        } else if (intersection(allReasonCodes, ReasonCodes.indefiniteHold.checkWith).length > 0) {
            return this.filterPrescriptions(prescriptions, ReasonCodes.indefiniteHold);
        } else {
            return this.orderResolved();
        }
    }

    onShipConsentHoldAlert(prescriptions, allReasonCodes) {
        if (intersection(allReasonCodes, ReasonCodes.consentShip.checkWith).length > 0) {
            return this.filterPrescriptions(prescriptions, ReasonCodes.consentShip);
        } else if (intersection(allReasonCodes, ReasonCodes.indefiniteHold.checkWith).length > 0) {
            return this.filterPrescriptions(prescriptions, ReasonCodes.indefiniteHold);
        } else {
            return this.orderResolved();
        }
    }

    onIndefiniteHoldAlert(prescriptions, allReasonCodes) {
        if (intersection(allReasonCodes, ReasonCodes.indefiniteHold.checkWith).length > 0) {
            return this.filterPrescriptions(prescriptions, ReasonCodes.indefiniteHold);
        } else {
            return this.orderResolved();
        }
    }

    filterPrescriptions(prescriptions, reasonCodes) {
        const filteredPrescription = prescriptions
            .filter((prescription) => reasonCodes.exclude && reasonCodes.exclude.indexOf(prescription.reasonCode) < 0)
            .map((prescription) => {
                return {
                    ...prescription,
                    drugFullName: this._capitalize.transform(prescription.drugName) + ' ' + prescription.drugStrength.toLowerCase() + ' ' + this._capitalize.transform(prescription.drugDosage),
                    drugName: this._capitalize.transform(prescription.drugName),
                    drugStrengthAndDosage: prescription.drugStrength.toLowerCase() + ' ' + this._capitalize.transform(prescription.drugDosage),
                    daysSupplyQuantity: prescription.daysSupplyQuantity,
                    dispensedQuantity: parseInt(prescription.dispensedQuantity, 10),
                    rxNumber: prescription.rxNumber,
                    payAmount: parseFloat(prescription.payAmount || 0)
                };
            });
        const displayRx = [];
        const otherRx = [];
        each(filteredPrescription, (prescription) => {
            if (!reasonCodes.displayRx.length || reasonCodes.displayRx.indexOf(prescription.reasonCode) > -1) {
                displayRx.push(prescription);
            } else {
                otherRx.push(prescription);
            }
        });
        // console.log(filteredPrescription);
        // console.log(displayRx);
        // console.log(otherRx);
        return {
            reasonCode: reasonCodes.reasonCode,
            displayRx : displayRx,
            otherRx   : otherRx
        };
    }

    orderResolved() {
        return {
            reasonCode : 0,
            displayRx  : [],
            otherRx    : []
        };
    }

    findRxList(prescriptions) {
        const rx = [];
        prescriptions.forEach((prescription) => {
            rx.push({
                drugFullName: `${this._capitalize.transform(prescription.drugName)} ${prescription.drugStrength.toLowerCase()} ${this._capitalize.transform(prescription.drugDosage)}`,
                drugName: this._capitalize.transform(prescription.drugName),
                drugStrengthAndDosage: `${prescription.drugStrength.toLowerCase()} ${this._capitalize.transform(prescription.drugDosage)}`,
                daysSupplyQuantity: prescription.daysSupplyQuantity,
                dispensedQuantity: parseInt(prescription.dispensedQuantity, 10),
                rxNumber: prescription.rxNumber,
                payAmount: parseInt(prescription.payAmount, 10)
            });
        });
        return rx;
    }

    setShippingAndPaymentDetails(response) {
        if (response.ElectronicPaymentAccountList.ElectronicPaymentAccount) {
          this.subject.paymentsList.next(
            this.setPaymentList(response.ElectronicPaymentAccountList.ElectronicPaymentAccount)
          );
        }
        if (response.AddressList.Address) {
          this.subject.addressDetails.next(
            this.setAddressList(response.AddressList.Address)
          );
        }
        if (response.ShippingMethodList.ShippingMethod) {
          this.subject.shippingMethod.next(
            {
              shippingMethods: this.setShippingMethod(response.ShippingMethodList.ShippingMethod),
              selectedMethod: this.subject.shippingMethod.value.selectedMethod || null
            }
          );
        }
    }

    updateSelectedAddress(address) {
        this.subject.addressDetails.next({
            ...this.subject.addressDetails.value,
            selectedAddress: address
        });
    }

    updateShippmingMethod(i) {
        const value = this.subject.shippingMethod.value;
        this.subject.shippingMethod.next({
            ...value,
            selectedMethod: value.shippingMethods[i]
        });
    }

    updateCost(cost: number) {
        this.subject.accountBalance.next({
            ...this.subject.accountBalance.value,
            estimatedCost: this.subject.accountBalance.value.estimatedCost + cost
        });
    }

    updateShippingCost(cost: number) {
        this.subject.accountBalance.next({
            ...this.subject.accountBalance.value,
            shippingCost: cost
        });
    }

    setSelectedRx(rxList) {
        this.subject.orderDetails.next({
            ...this.subject.orderDetails.value,
            selectedRx: rxList
        });
    }

    getRxList() {
        return this.subject.orderDetails.value.selectedRx || this.subject.orderDetails.value.rxList;
    }

    getAddress(address) {
        return {
            ...address,
            fullName: `${this._capitalize.transform(address.firstName + ' ' + address.lastName)}`,
            addressLine: `${this._capitalize.transform(address.line1 + ', ' + address.city)} ${address.state} ${address.zipCode}`
        };
    }

    getOrderNumber() {
        return this.subject.orderDetails.value.orderNumber;
    }

    getAccountBalance(order) {
        let estimatedCost = 0;
        let shippingCost = 0;
        const orderDetails = this.subject.orderDetails.value;
        if (orderDetails.displayRx.length && orderDetails.reasonCode === CONSENTS.PAYMENT_ONLY) {
            estimatedCost = parseFloat(this.subject.orderDetails.value.displayRx.reduce((total, rx) => rx.payAmount + total, 0));
        } else {
            estimatedCost = parseFloat(order.payAmount || 0);
        }
        if (orderDetails.reasonCode === CONSENTS.INDEFINITE_HOLD) {
            shippingCost = 0;
        } else {
            shippingCost = parseFloat(order.shippingCost || 0);
        }
        const outstandingBalance = parseFloat(order.orderBalanceAmount || 0);
        return {
            estimatedCost: estimatedCost,
            shippingCost: shippingCost,
            outstandingBalance: outstandingBalance,
            totalDue: 0,
            isMedD: orderDetails.reasonCode === CONSENTS.MED_D_SHIPMENT ? true : false
        };
    }

    setUpdateAccountBalance(accountBalance) {
        this.updatedAccountBalance = accountBalance;
    }

    private getExpirationDetais(expiry) {
        const month = parseInt(expiry.split('/')[0], 10) - 1;
        const year = parseInt(expiry.split('/')[1], 10);
        const factor = environment.ccExpiredDateFactor;
        const card = new Date(year, month);
        const today = new Date();
        const soon = new Date(card.getFullYear(), card.getMonth() - factor);
        if (card < new Date()) {
            return { text: Contents.expiration.expired, class: 'expired' };
        } else if ( today < card && today > soon ) {
            return { text: Contents.expiration.soon, class: 'expire-soon' };
        } else {
            return;
        }
    }

    setPaymentList(payments): PaymentList {
        if (!Array.isArray(payments)) {
            payments = [payments];
        }
        let paymentsList: any, selectedPayment: any;
        payments.forEach((payment) => {
            if ( payment.ExpirationDate ) {
              payment.expire = this.getExpirationDetais(payment.ExpirationDate);
            }
            switch (payment.ElectronicPaymentAccountType) {
                case 'CC':
                    payment.type = 'card';
                    break;
                case 'ECP':
                    payment.type = 'bank';
                    break;
                default:
                    break;
            }
        });
        paymentsList = groupBy(payments, 'type');
        if (this.subject.orderDetails.value.reasonCode !== CONSENTS.MED_D_SHIPMENT) {
            // selectedPayment = paymentsList.card ? paymentsList.card[0] : {};
        } else {
            selectedPayment = this.subject.orderDetails.value.paymentAccount;
        }
        return Object.assign({}, paymentsList, {
            selectedPayment: selectedPayment,
            editPayment: null
        });
    }

    setAddressList(addressList) {
        if (!Array.isArray(addressList)) {
            addressList = [addressList];
        }
        addressList = addressList.map((address) => {
            const line1 = (address.Line1) ? this._capitalize.transform(address.Line1) : '';
            const line2 = (address.Line2) ? this._capitalize.transform(address.Line2) : '';
            const city = this._capitalize.transform(address.City);
            return {
                ...address,
                Line1: line1,
                Line2: line2,
                City: city,
                FullAddress: `${line1} ${city + ','} ${address.State} ${address.ZipCode}`
            };
        });
        return { addressList: addressList, selectedAddress: null };
    }

    setShippingMethod(shippingMethods) {
        const shippingCodes = ['B', 'D', 'J'];
        return filter(shippingMethods, (method) => {
            return shippingCodes.indexOf(method.ShippingCode) > -1;
        }).map((method) => {
            return {
                ...method,
                Description: this._capitalize.transform(method.Description)
            };
        });
    }

    setSelectedShippingMethod(code) {
      if (this.subject.shippingMethod.value.shippingMethods) {
        const selected = this.subject.shippingMethod.value.shippingMethods.filter((method) => method.ShippingCode === code)[0];
        this.subject.shippingMethod.value.selectedMethod = selected;
      }
    }


    updateCard(cardDetails) {
        const expiration = `${cardDetails.expiryMonth}/${cardDetails.expiryYear}`;
        const updatedCard = this.subject.paymentsList.value.card.map((card) => {
            if (card.AccountName === cardDetails.cardNumber) {
                return {
                    ...card,
                    ExpirationDate: expiration,
                    expire: this.getExpirationDetais(expiration)
                };
            }
            return card;
        });
        this.subject.paymentsList.next({
            ...this.subject.paymentsList.value,
            card: updatedCard
        });
    }

    addCard(cardDetails) {
        const expiration = `${cardDetails.expiryMonth}/${cardDetails.expiryYear}`;
        let accountName = '';
        if (cardDetails.cardNumber) {
            accountName =  Utils.getCreditCardType(cardDetails.cardNumber) + '-' + cardDetails.cardNumber.toString().slice(-4);
        }
        const newCard = {
            AccountName: accountName,
            ElectronicPaymentAccountType: 'CC',
            type: 'card',
            ExpirationDate: expiration,
            expire: this.getExpirationDetais(expiration)
        };
        this.subject.paymentsList.next({
            ...this.subject.paymentsList.value,
            card: [...this.subject.paymentsList.value.card, newCard]
        });
    }

    addBank(bankDetails) {
        const accountNo = bankDetails.accountNumber;
        if (!this.subject.paymentsList.value.bank) {
            this.subject.paymentsList.value.bank = [];
        }
        this.subject.paymentsList.value.bank.push({
            AccountName: 'DISC-' + accountNo.toString().slice(-4)
        });
    }

    setSelectedPayment(key, index) {
        this.subject.paymentsList.next({
            ...this.subject.paymentsList.value,
            selectedPayment: this.subject.paymentsList.value[key][index]
        });
    }

    setSelectedPaymentFromOnHoldResponse() {
        this.subject.paymentsList.next({
            ...this.subject.paymentsList.value,
            selectedPayment: this.subject.orderDetails.value.paymentAccount
        });
    }

    setEditPayment(payment) {
        let editPayment = null;
        if (payment) {
            editPayment = {
                index: payment,
                details: this.subject.paymentsList.value[payment.type][payment.index]
            };
        }
        this.subject.paymentsList.next({
            ...this.subject.paymentsList.value,
            editPayment: editPayment
        });
    }

    getSelectedPayment() {
        return this.subject.paymentsList.value.selectedPayment;
    }

    getSelectedCardNumber() {
        return (this.subject.paymentsList.value.selectedPayment && this.subject.paymentsList.value.selectedPayment.AccountName) ?
          this.subject.paymentsList.value.selectedPayment.AccountName.split('-')[1] : '';
    }

    getSelectedCardExpiration() {
        if (this.subject.paymentsList.value.selectedPayment && this.subject.paymentsList.value.selectedPayment.ExpirationDate) {
            const expiration = this.subject.paymentsList.value.selectedPayment.ExpirationDate;
            return {
                month: expiration.split('/')[0],
                year: expiration.split('/')[1],
            };
        }
    }

    setOnHoldReleaseStatus(status: RELEASE_STATUS) {
        this.onHoldReleaseStatus = status;
    }

    getOnHoldReleaseStatus(): RELEASE_STATUS {
        return this.onHoldReleaseStatus;
    }

    saveComponentState(state: any) {
        this.subject.componentState.next(state);
    }

    getComponentState() {
        return this.componentState;
    }

    clearComponentState() {
        this.componentState = null;
    }

    getResolveOnHoldPayload(medicationList = null, releaseStatus) {
        const medications = medicationList || this.getRxList() || [];
        const cardExpiration: any = this.getSelectedCardExpiration();
        let accountId = '0';
        let paymentTypeCode = 0;
        let serviceCD = 'DOR';
        const reasonCode = this.subject.orderDetails.value.reasonCode;
        const selectedPayment = this.subject.paymentsList.value.selectedPayment;
        if (reasonCode === REASON_CODES.INDEFINITE_HOLD) {
            serviceCD = 'HLD';
        }
        if (selectedPayment) {
            accountId = selectedPayment.ePayAccountID ||
            selectedPayment.ElectronicPaymentAccountID;
            paymentTypeCode = parseInt(selectedPayment.PaymentTypeCode, 10) ||
              parseInt(selectedPayment.paymentTypeCode, 10);
        }
        return {
            actionCD: releaseStatus === RELEASE_STATUS.RELEASED ? 'U' : 'C',
            serviceCD: serviceCD,
            orderNumber: this.subject.orderDetails.value.orderNumber,
            accountID: accountId,
            paymentTypecd: paymentTypeCode ? paymentTypeCode : 0,
            last4DigitsOfCreditCard: this.getSelectedCardNumber() ? this.getSelectedCardNumber() : '0000' ,
            cardExpirationMonth: cardExpiration ? parseInt(cardExpiration.month, 10) : 0,
            cardExpirationYear: cardExpiration ? (parseInt(cardExpiration.year, 10) % 100) : 0,
            processSourceCode: 'DPT',
            rxLevelArrayCount: medications.length,
            rxLevelArray: medications.map((medication) => {
              return {
                LineItemNumber: parseInt(medication.rxLineItemNumber, 10),
                rxNumber: medication.rxNumber,
                nrcCD: parseInt(medication.orderType, 10),
                pmtPrblmResultCd: (medication.isSelected || medication.isSelected === undefined) ? 'Y' : 'N',
                reasonCd: medication.reasonCode
              };
            })
        };
    }

    private getAddressForMED(address) {
        return {
            address1: {
                '__cdata': address.line1
            },
            address2: {
                '__cdata': address.line2
            },
            city: address.city,
            state: address.state,
            zipCode: address.zipCode,
            zipSuffixCode: '0000',
            shippingMethod: this.subject.orderDetails.value.shipMethod,
            shippingCost: this.subject.orderDetails.value.shippingCost,
            usageTypeCode: address.UsageTypeCode
        };
    }

    private getAddressForIndefenite(address) {
        if (address) {
            let zipSuffix = address.ZipCodeSuffix || '0000';
            let zipCode = '00000';
            if (address.ZipCode && address.ZipCode.length > 5) {
                zipSuffix = address.ZipCode.slice(-4);
            } else if (address.zipCode && address.zipCode.length > 5) {
                zipSuffix = address.zipCode.slice(-4);
            }
            if (address.ZipCode || address.zipCode) {
                zipCode = (address.ZipCode || address.zipCode).slice(0, 5);
            }
            return {
                address1: {
                    '__cdata': address.Line1 || address.address || ''
                },
                address2: {
                    '__cdata': address.Line2 || ''
                },
                city: address.City || address.city || '',
                state: address.State || address.state || '',
                zipCode: zipCode,
                zipSuffixCode: zipSuffix,
                shippingMethod: this.subject.shippingMethod.value.selectedMethod.ShippingCode || '',
                shippingCost: this.subject.shippingMethod.value.selectedMethod.ShippingCost || 0,
                usageTypeCode: address.UsageTypeCode || 0
            };
        }
    }

    getMultiplePlaceOrderPayload(selectedRx, isFromMedD) {
        const orderDetails = { shippingDetails: {}, paymentDetails: {}, prescriptionsDetails: {}, memberDetails: {} };
        const address = isFromMedD ? this.subject.orderDetails.value.shippingAddress : this.subject.addressDetails.value.selectedAddress;

        orderDetails.shippingDetails = isFromMedD ? this.getAddressForMED(address) : this.getAddressForIndefenite(address);
        const outstandingBalance = this.subject.orderDetails.value.outstandingBalance ?
          this.subject.orderDetails.value.outstandingBalance : '0.0';
        let electronicPaymentId = '';
        if (isFromMedD) {
            electronicPaymentId = this.subject.orderDetails.value.paymentAccount.ePayAccountID;
        } else {
            electronicPaymentId = this.subject.paymentsList.value.selectedPayment.ElectronicPaymentAccountID;
        }
        orderDetails.paymentDetails = {
            outstandingBalance: outstandingBalance,
            electronicPaymentId: electronicPaymentId
        };

        const rxNumberSelected = selectedRx.filter((rx) => !isFromMedD || rx.isSelected).map((rx) => rx.rxNumber );

        orderDetails.prescriptionsDetails = {
            refillRx: {
                rxNumber: rxNumberSelected
            }
        };
        orderDetails.memberDetails = {
            emailAddress: this.subject.orderDetails.value.contactEmail
        };
        return { orderDetails };
    }

}
