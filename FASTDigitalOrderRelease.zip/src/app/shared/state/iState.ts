import { BehaviorSubject } from 'rxjs/BehaviorSubject';

export interface ShippingAddress {
    firstName: string;
    lastName: string;
    line1: string;
    line2: string;
    city: string;
    state: string;
    zipCode: string;
    zipCodeSuffix: string;
    fullName: string;
    addressLine: string;
    usageTypeCode: number;
}

export interface PaymentList {
    bank?: any[];
    card?: any[];
    selectedPayment: any;
    editPayment: {
        index: {},
        details: {}
    } | null;
}

export interface iShipMethod {
    Description: string;
    ShippingCode: string;
    ShippingCost: string;
}

export interface ShippingMethod {
    shippingMethods: iShipMethod[] | null;
    selectedMethod: iShipMethod;
}

export interface AddressDetails {
    addressList: any;
    selectedAddress: any;
}

export interface OrderDetails {
    orderNumber: string;
    rxList: any[];
    shippingAddress: ShippingAddress;
    orderPlaced: any;
    orderTimeToRelease: any;
    shippingCost: any;
    outstandingBalance: any;
    payAmount: any;
    contactEmail: string;
    topLevelMessage: string;
    reasonCode: number;
    displayRx: any[];
    otherRx: any[];
    selectedRx: any[];
    shipMethod: string;
    bannerMsg: string;
    paymentAccount: any;
    participantId: string | number;
}

export interface AccountBalance {
    estimatedCost: number;
    shippingCost: number;
    outstandingBalance: number;
    totalDue: number;
    isMedD: boolean;
}
export interface ShippingError {
    isError: boolean;
}
export interface State {
    orderDetails: BehaviorSubject<OrderDetails>;
    paymentsList: BehaviorSubject<PaymentList>;
    accountBalance: BehaviorSubject<AccountBalance>;
    addressDetails: BehaviorSubject<AddressDetails>;
    shippingMethod: BehaviorSubject<ShippingMethod>;
    componentState: BehaviorSubject<any>;
    shippingError: BehaviorSubject<ShippingError>;
}

const initialOrderDetails = {
    orderNumber: '',
    rxList: [],
    shippingAddress: {
        firstName: '',
        lastName: '',
        line1: '',
        line2: '',
        city: '',
        state: '',
        zipCode: '',
        zipCodeSuffix: '',
        fullName: '',
        addressLine: '',
        usageTypeCode: 0
    },
    orderPlaced: '',
    orderTimeToRelease: '',
    shippingCost: '',
    outstandingBalance: '',
    payAmount: '',
    contactEmail: '',
    topLevelMessage: '',
    reasonCode: 0,
    displayRx: [],
    otherRx: [],
    selectedRx: null,
    shipMethod: '',
    bannerMsg: '',
    paymentAccount: null,
    participantId: ''
};

const initialAccountBalance = {
    estimatedCost: 0,
    shippingCost: 0,
    outstandingBalance: 0,
    totalDue: 0,
    isMedD: false
};

const initialPaymentList = {
    bank: [],
    card: [],
    selectedPayment: {},
    editPayment: null
};

const initialComponentState = null;

const initialShippingMethod = {
    shippingMethods: null,
    selectedMethod: null
};
const initialAddressDetails = {
    addressList: [],
    selectedAddress: null
};
const initialShippingError = {
    isError: false
};

export const InitialState: State = {
    orderDetails: new BehaviorSubject<OrderDetails>(initialOrderDetails),
    paymentsList: new BehaviorSubject<PaymentList>(initialPaymentList),
    accountBalance: new BehaviorSubject<AccountBalance>(initialAccountBalance),
    addressDetails: new BehaviorSubject<any>(initialAddressDetails),
    shippingMethod: new BehaviorSubject<ShippingMethod>(initialShippingMethod),
    componentState: new BehaviorSubject<any>(initialComponentState),
    shippingError: new BehaviorSubject<ShippingError>(initialShippingError)
};
