/**
 * Deep Readonly type 
 */
export type DeepReadonly<T> = { readonly [K in keyof T]: DeepReadonly<T[K]> };

/**
 * boolean used as string (usually service returns this type of boolean in response)
 */
export type StringBool = 'true' | 'false';

export type Callback = (data: any) => void;