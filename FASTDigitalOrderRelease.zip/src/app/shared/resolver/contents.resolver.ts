import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { BackEndService } from '../services/index';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import { catchError } from 'rxjs/operators/catchError';

@Injectable()
export class ContentsResolver implements Resolve<any> {

    isInitiated = false;

    resolve(): Observable<any> {
        if (!this.isInitiated) {
            this.isInitiated = true;
            return this._backEnd.initOnHoldDetailsAndShipping().pipe(
                catchError((e) => Observable.of(null))
            );
        } else {
            return Observable.of('success');
        }
    }

    constructor(private _backEnd: BackEndService) {}

}
