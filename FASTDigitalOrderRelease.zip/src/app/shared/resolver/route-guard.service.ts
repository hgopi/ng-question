import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AppState } from '../state/AppState';
import { ROUTE_PATHS } from '../enum';
import { Utils } from '../utils';


@Injectable()
export class RouteGuard implements CanActivate {

    constructor(private _appState: AppState, private _router: Router) {}

    canActivate(): boolean {
        // return true;
        if (!this._appState.isOrderDetailsSet) {
            this._router.navigate([ROUTE_PATHS.INDEX], {queryParams: Utils.getParams()});
        }
        return this._appState.isOrderDetailsSet;
    }

}
