import { Pipe, PipeTransform } from '@angular/core';
import { CARD_TYPE_SHORT } from './../enum';
import { CapitalizePipe } from './capitalize.pipe';

@Pipe({
    name: 'cardTitle'
})
export class CardTitlePipe implements PipeTransform {

    constructor(private _capitalize: CapitalizePipe) {}

    transform(value: any, ...args: any[]) {
        if (!value) { return value; }
        return this._capitalize.transform(CARD_TYPE_SHORT[value] || 'Card');
    }
}
