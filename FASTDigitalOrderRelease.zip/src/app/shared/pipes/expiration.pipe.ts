import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'expiration'
})
export class ExpirationPipe implements PipeTransform {

    transform(value: any, ...args: any[]) {
        if (!value) {
            return value;
        }

        return value.split('/').map((ex) => ex.length < 2 ? `0${ex}` : ex.length > 2 ? ex.slice(-2) : ex).join('/');

    }

}
