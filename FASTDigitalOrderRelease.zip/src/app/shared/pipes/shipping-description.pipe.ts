import { Pipe, PipeTransform } from "@angular/core";

export enum SHIP_DESCRIPTION {
    'B' = 'Standard delivery',
    'J' = '2-day delivery',
    'D' = 'Overnight delivery'
}

@Pipe({
    name: 'shipDescription'
})
export class ShipDescription implements PipeTransform {
    transform(value: any, ...args: any[]) {
        if (!value || !(value in SHIP_DESCRIPTION)) {
            return value;
        }
        return SHIP_DESCRIPTION[value];
    }
}
