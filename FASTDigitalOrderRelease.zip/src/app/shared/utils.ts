import { IEnvironmentConfig } from './models/config/environment-config';
import { ENV_MODE } from './enum';

export class Utils {
    static currentQueryParam = '';
    static userAgent = '';
    static cardTypesRegex = {
        AMERICAN: '^(34)|^(37)',
        DISCOVER: '^(6011)|^(622(1(2[6-9]|[3-9][0-9])|[2-8][0-9]{2}|9([01][0-9]|2[0-5])))|^(64[4-9])|^65',
        MASTERCARD: '^(?:((222[1-9])[0-9]{12}|(22[3-9][0-9])[0-9]{12}|(2[3-6])[0-9]{14}|(27[0-1])[0-9]{13}|(2720)[0-9]{12}|(5[1-5])[0-9]{14}))',
        VISA: '^4'
    };

    static get guid() {
        function s4() {
          return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
        }
        return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
          s4() + '-' + s4() + s4() + s4();
    }

    static getParams(obj = window) {
        const query = obj.location.search
            || obj.location.hash && obj.location.hash.split('?').length > 1 && obj.location.hash.split('?')[1]
            || '';
        this.currentQueryParam = query;
        return (/^[?#]/.test(query) ? query.slice(1) : query)
            .split('&')
            .reduce((params, param) => {
                const [key, value] = param.split('=');
                params[key] = value ? decodeURIComponent(value.replace(/\+/g, ' ')) : '';
                return params;
            }, {});
    }

    static appendQueryParam(obj = window) {
        const query = obj.location.search
            || obj.location.hash && obj.location.hash.split('?').length > 1 && obj.location.hash.split('?')[1]
            || '';
        return query;
    }

    static isMobile() {
        const userAgent = navigator.userAgent;
        if (userAgent.match(/Android/i)
            || userAgent.match(/webOS/i)
            || userAgent.match(/iPhone/i)
            || userAgent.match(/iPad/i)
            || userAgent.match(/iPod/i)
            || userAgent.match(/BlackBerry/i)
            || userAgent.match(/Windows Phone/i)
        ) {
            return true;
        } else {
            return false;
        }
    }

    static getNativeWindow() {
        return <any>window;
    }

    static isInIframe() {
        let isSameOrigin = false;
        try {
            if (<any>window.top !== <any>window.self) {
                isSameOrigin = true;
            }
        } catch (e) {}
        return isSameOrigin;
    }

    static findPosition(obj: HTMLElement) {
        let curleft = 0, curtop = 0;
        if (obj.offsetParent) {
            do {
                curleft += obj.offsetLeft;
                curtop += obj.offsetTop;
            } while (obj = <HTMLElement>obj.offsetParent);
        }
        return { top: curtop, left: curleft };
    }

    static scrollToParentTop() {
        if (Utils.isInIframe()) {
            try {
                const iframeContainer = <HTMLElement>window.parent.document.getElementById('fast-container');
                const parentOffset = Utils.findPosition(iframeContainer);
                const paddingTop = parseInt(window.getComputedStyle(iframeContainer, null).getPropertyValue('padding-top'), 10);
                setTimeout(() => { window.parent.scrollTo(0, parentOffset.top + paddingTop); }, 100);
            } catch (e) { console.log(e); }
        }
    }

    static getSessionValue(key) {
        let val;
        try {
            val = sessionStorage.getItem(key);
        } catch (e) {
            console.log(e);
        }
        return val;
    }

    static setSessionValue(key, value) {
        try {
            sessionStorage.setItem(key, value);
        } catch (e) {
            console.log(e);
        }
    }

    static positionModalDialog() {
        try {
            let top = window.parent.scrollY;
            const modalHeight = document.querySelector('.modal .modal-content').getBoundingClientRect().height;
            if (top + modalHeight > window.document.documentElement.clientHeight) {
                top = 100;
                window.parent.scrollTo(0, 0);
            }
            return top;
        } catch (e) { return 0; }
    }

    static getUserAgent () {
        const userAgent = navigator.userAgent;
        if (this.userAgent) {
            return this.userAgent;
        }
        if (/Android/i.test(userAgent)) { // ANDROID
            if (/Mobile/i.test(userAgent)) { // ANDROID MOBILE
                this.userAgent = 'AND_MOBILE';
            } else if (/Glass/i.test(userAgent)) { // ANDROID GLASS
                this.userAgent = 'AND_GLASS';
            } else { // ANDROID TABLET
                this.userAgent = 'AND_TABLET';
            }
        } else if (/iPhone|iPod/i.test(userAgent)) { // iOS Mobile
            this.userAgent = 'IOS_MOBILE';
        } else if (/iPad/i.test(userAgent)) { // iOS Tablet
            this.userAgent = 'IOS_TABLET';
        } else if (/IEMobile/i.test(userAgent)) { // Windows
            this.userAgent = 'WIN_MOBILE';
        } else if (/webOS|BlackBerry|Opera Mini/i.test(userAgent)) { // Other identified vendor
            this.userAgent = 'OTH_MOBILE';
        } else {
            this.userAgent = 'DESKTOP';
        }
        return this.userAgent;
    }

    static get channelType() {
        const deviceType = Utils.getUserAgent();
        let channelType = '';
        switch (deviceType) {
            case 'IOS_TABLET':
            channelType = 'Web_TabIOS';
            break;
            case 'AND_TABLET':
            channelType = 'Web_TabAnd';
            break;
            case 'IOS_MOBILE':
            channelType = 'Web_MobIOS';
            break;
            case 'AND_MOBILE':
            channelType = 'Web_MobAnd';
            break;
            default:
            channelType = 'Web';
            break;
        }
        return channelType;
    }

    static getSystemId(data: IEnvironmentConfig) {
        const deviceType = Utils.getUserAgent();
        let systemID;
        if (data.mode === ENV_MODE.MAPP) {
          systemID = (deviceType === 'AND_MOBILE') ? 'Por_AndAP' : 'Por_IOSAp';
        } else {
          systemID = (deviceType === 'DESKTOP') ? 'Portal' : 'Por_Mob';
        }
        return systemID;
    }
    static fortmatDateTime(date, format, utc = undefined) {
        const MMMM = ['\x00', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        const MMM = ['\x01', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const dddd = ['\x02', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const ddd = ['\x03', 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        function ii(i, len = null) {
          let s = i + '';
          len = len || 2;
          while (s.length < len) {
            s = '0' + s;
          }
          return s;
        }

        const y = utc ? date.getUTCFullYear() : date.getFullYear();
        format = format.replace(/(^|[^\\])yyyy+/g, '$1' + y);
        format = format.replace(/(^|[^\\])yy/g, '$1' + y.toString().substr(2, 2));
        format = format.replace(/(^|[^\\])y/g, '$1' + y);

        const M = (utc ? date.getUTCMonth() : date.getMonth()) + 1;
        format = format.replace(/(^|[^\\])MMMM+/g, '$1' + MMMM[0]);
        format = format.replace(/(^|[^\\])MMM/g, '$1' + MMM[0]);
        format = format.replace(/(^|[^\\])MM/g, '$1' + ii(M));
        format = format.replace(/(^|[^\\])M/g, '$1' + M);

        const d = utc ? date.getUTCDate() : date.getDate();
        format = format.replace(/(^|[^\\])dddd+/g, '$1' + dddd[0]);
        format = format.replace(/(^|[^\\])ddd/g, '$1' + ddd[0]);
        format = format.replace(/(^|[^\\])dd/g, '$1' + ii(d));
        format = format.replace(/(^|[^\\])d/g, '$1' + d);

        const H = utc ? date.getUTCHours() : date.getHours();
        format = format.replace(/(^|[^\\])HH+/g, '$1' + ii(H));
        format = format.replace(/(^|[^\\])H/g, '$1' + H);

        const h = H > 12 ? H - 12 : H === 0 ? 12 : H;
        format = format.replace(/(^|[^\\])hh+/g, '$1' + ii(h));
        format = format.replace(/(^|[^\\])h/g, '$1' + h);

        const m = utc ? date.getUTCMinutes() : date.getMinutes();
        format = format.replace(/(^|[^\\])mm+/g, '$1' + ii(m));
        format = format.replace(/(^|[^\\])m/g, '$1' + m);

        const s = utc ? date.getUTCSeconds() : date.getSeconds();
        format = format.replace(/(^|[^\\])ss+/g, '$1' + ii(s));
        format = format.replace(/(^|[^\\])s/g, '$1' + s);

        let f = utc ? date.getUTCMilliseconds() : date.getMilliseconds();
        format = format.replace(/(^|[^\\])fff+/g, '$1' + ii(f, 3));
        f = Math.round(f / 10);
        format = format.replace(/(^|[^\\])ff/g, '$1' + ii(f));
        f = Math.round(f / 10);
        format = format.replace(/(^|[^\\])f/g, '$1' + f);

        const T = H < 12 ? 'AM' : 'PM';
        format = format.replace(/(^|[^\\])TT+/g, '$1' + T);
        format = format.replace(/(^|[^\\])T/g, '$1' + T.charAt(0));

        const t = T.toLowerCase();
        format = format.replace(/(^|[^\\])tt+/g, '$1' + t);
        format = format.replace(/(^|[^\\])t/g, '$1' + t.charAt(0));

        let tz = -date.getTimezoneOffset();
        let K = utc || !tz ? 'Z' : tz > 0 ? '+' : '-';
        if (!utc) {
          tz = Math.abs(tz);
          const tzHrs = Math.floor(tz / 60);
          const tzMin = tz % 60;
          K += ii(tzHrs) + ':' + ii(tzMin);
        }
        format = format.replace(/(^|[^\\])K/g, '$1' + K);

        const day = (utc ? date.getUTCDay() : date.getDay()) + 1;
        format = format.replace(new RegExp(dddd[0], 'g'), dddd[day]);
        format = format.replace(new RegExp(ddd[0], 'g'), ddd[day]);

        format = format.replace(new RegExp(MMMM[0], 'g'), MMMM[M]);
        format = format.replace(new RegExp(MMM[0], 'g'), MMM[M]);

        format = format.replace(/\\(.)/g, '$1');

        return format;
    }

    static getCreditCardType(cardNumber) {
        cardNumber = cardNumber.toString().replace(/\s/g, '');
        if (new RegExp(Utils.cardTypesRegex.AMERICAN).test(cardNumber)) {
            return 'American Express';
        } else if (new RegExp(Utils.cardTypesRegex.DISCOVER).test(cardNumber)) {
            return 'Discover Card';
        } else if (new RegExp(Utils.cardTypesRegex.MASTERCARD).test(cardNumber)) {
            return 'MasterCard';
        } else if (new RegExp(Utils.cardTypesRegex.VISA).test(cardNumber)) {
            return 'Visa';
        } else {
            return '';
        }
    }

    static scrollToTop() {
        if (window.parent) {
            window.parent.scrollTo(0, 0);
        } else {
            window.scrollTo(0, 0);
        }
    }

}
