export enum ROUTE_PATHS {
    INDEX = '',
    CONFIRMATION = 'confirmation',
    EDIT_CARD = 'edit-card',
    EDIT_BANK_ACC = 'edit-bank-account',
}

export enum CONSENTS {
    RX_AND_PAYMENT = 1,
    PAYMENT_ONLY,
    MED_D_SHIPMENT,
    INDEFINITE_HOLD
}

export enum ENV {
    prod = 1,
    cte,
    stp,
    sit1,
    sit2,
    sit3,
    dev1,
    dev2,
    dev3,
    demo
}

export enum ENV_MODE {
    STANDALONE = 1,
    PORTAL,
    MAPP
}

export enum VERSION {
    V1 = 1,
    V2
}

export enum ALERT_TYPE {
    NONE = '',
    SUCCESS = 'success',
    ERROR = 'error',
    WARNING = 'warning',
    INFO = 'info'
}

export enum RELEASE_STATUS {
    RELEASED = 1,
    CANCELLED,
}

export enum ORDER_ALERT_TYPE {
    PAYMENT_HOLD = 'paymentHoldAlert',
    SHIPMENT_CONSENT_HOLD = 'shipConsentHoldAlert',
    INDEFINITE_HOLD = 'indefiniteHoldAlert',
    PPT_HOLD = 'pptHoldAlert'
}

export enum STATES {
    ORDER_DETAILS = 'orderDetails',
    PAYMENTS_LIST = 'paymentsList',
    ACCOUNT_BALANCE = 'accountBalance',
    ADDRESS_LIST = 'addressDetails',
    SHIPPING_METHOD = 'shippingMethod',
    COMPONENT_STATE = 'componentState',
    SHIPPING_ERROR = 'shippingError'
}

export enum CARD_TYPE {
    'DISCOVER CARD' = 7,
    'MASTERCARD' = 10,
    'VISA' = 14,
    'AMERICAN EXPR.' = 24,
    'BILL ME LATER' = 39,
    'E-CHECK' = 40,
    'Installment Pmt' = 41
}

export enum CARD_TYPE_SHORT {
    'DISC' = 7,
    'MC' = 10,
    'VISA' = 14,
    'AMEX' = 24
}

export enum REASON_CODES {
    CONSENT_PAY = 1,
    PAYMENT_ALERT,
    CONSENT_SHIP,
    INDEFINITE_HOLD
}
