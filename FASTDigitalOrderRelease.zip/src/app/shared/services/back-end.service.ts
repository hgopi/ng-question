import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { map, switchMap, mergeMap, flatMap } from 'rxjs/operators';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { environment } from '../../../environments/environment';
import { has } from 'lodash';
import { AppState } from '../state/AppState';
import * as CryptoJS from 'crypto-js';
import { ENV, RELEASE_STATUS } from '../enum';
import { catchError } from 'rxjs/operators/catchError';
import 'rxjs/add/observable/throw';
import { EccrService, INTERACTION_STATUS, INTERACTION_TYPE } from './eccr.service';
import { TealiumUtagService } from './utag.service';
import { Tagging } from '../config/tagging-constants';
import { fromPromise } from 'rxjs/observable/fromPromise';

declare let FASTConfig: any;

@Injectable()
export class BackEndService {

    constructor(
        private _http: HttpClient,
        private _appState: AppState,
        private _eccr: EccrService,
        private _analytics: TealiumUtagService
    ) { }

    private aesEncryption( string ) {
        const encrypted = CryptoJS.AES.encrypt(string, this.digestGenerator, {
            mode: CryptoJS.mode.ECB,
            padding: CryptoJS.pad.Pkcs7
        });
        return encrypted.ciphertext.toString(CryptoJS.enc.Base64);
    }

    private digestGenerator() {
        const digest = CryptoJS.SHA256('keytouse12345');
        digest.sigBytes = 16;
        return digest;
    }

    getOnHoldOrderDetails(): Observable<any> {
        return this._http.post('getOnHoldOrderDetails', Object.assign({}, {
            orderNumber: environment.orderNo,
            tokenID: environment.tokenID
        })).pipe(
            map((data: any) => {
                if (has(data, 'detail.order')) {
                    const additionalData = [];
                    this._appState.setOrderDetails(data.detail.order);
                    additionalData.push( {key: 'HOST_ID', value: 'NOT_AVAIL' } );
                    additionalData.push( {key: 'COMPONENT_ID', value: 'DIGITAL_ORDER_RELEASE' } );
                    additionalData.push( {key: 'FAST_INDICATOR', value: 'YES' } );
                    additionalData.push( {key: 'FAST_STYLE', value: 'caremark' } );
                    this._eccr.log(INTERACTION_TYPE.RELEASE_ORDER, INTERACTION_STATUS.COMPLETED, data.header ? data.header.refId : '', additionalData);
                }
            }),
            catchError((e) => {
                const hasCode = has(e, 'error.header.statusCode');
                const additionalData = [];
                this._appState.setServiceFailed();
                if (hasCode) {
                    additionalData.push({ key: 'ERROR_CODE', value: e.error.header.statusCode });
                    additionalData.push({ key: 'ERROR_DESC', value: e.error.header.statusDesc });
                    this._eccr.log(INTERACTION_TYPE.RELEASE_ORDER, INTERACTION_STATUS.FAILED, hasCode ? e.error.header.refId : '', additionalData);
                    this._analytics.view({
                        Error_Messages: `${e.error.header.statusCode}_getOnHoldOrderDetails_${e.error.header.statusDesc}`
                    });
                }
                return Observable.throw('error');
            })
        );
    }

    getShippingAndPayment(): Observable<any> {
        return this._http.post('getShippingAndPayment', Object.assign({}, {
        })).pipe(
            map((data: any) => {
                if (has(data, 'ShippingAndPaymentsResponse.ElectronicPaymentAccountList') && has(data, 'ShippingAndPaymentsResponse.AddressList')) {
                    this._appState.setShippingAndPaymentDetails(data.ShippingAndPaymentsResponse);
                }
                return data;
            }),
            catchError((e) => {
                return Observable.of({ error: e.status + ': ' + e.statusText });
            })
        );
    }

    private taggingErrorMessage(e, serviceName) {
        const hasCode = has(e, 'error.header.statusCode');
        let errorMessage = 'N/A';
        if (hasCode) {
            errorMessage = `${e.error.header.statusCode}_${serviceName}_${e.error.header.statusDESC}`;
        }
        this._analytics.view({
            Error_Messages: errorMessage
        });
    }

  addCreditCard(payload): Observable<any> {

      if (FASTConfig && FASTConfig.JoseEncryption) {
          return fromPromise(FASTConfig.JoseEncryption(payload.cardNumber))
            .pipe(
               map(encrypted => encrypted),
               switchMap((cardNumber) => {
                    return this.callAddCreditCardAPI(cardNumber, payload);
                }
            ),
            catchError((error) => {
                return this.callAddCreditCardAPI(this.aesEncryption(payload.cardNumber), payload);
            })
        );

    } else {
        return this.callAddCreditCardAPI(this.aesEncryption(payload.cardNumber), payload);

    }

  }
  callAddCreditCardAPI(cardNumber, payload) {
      return this._http.post('addCreditCard', cardNumber, {
        params: {
          creditCardExpiryYear: ('' + payload.expiryYear % 100),
          creditCardExpiryMonth: payload.expiryMonth > 9 ? payload.expiryMonth : `0${payload.expiryMonth}`
        }

      }).pipe(
        switchMap(() => {
            this._analytics.view({
                Page_Name: Tagging.AddCreditCardPageName,
                Page_Category: Tagging.OnHoldPageCategory
            });
            if (environment.env === ENV.demo) {
                this._appState.addCard(payload);
                // return Observable.of('success');
            }
            return this.getShippingAndPayment();
            
        }),
        catchError((e) => {
            console.log(e);
            this.taggingErrorMessage(e, 'addCreditCard');
            return Observable.throw('error');
        })
    );
  }


  updateCard(payload): Observable<any> {

        return this._http.post('updateCard', this.getUpdatedCardPayload(payload))
            .pipe(
                switchMap(() => {
                    this._analytics.view({
                        Page_Name: Tagging.AddCreditCardPageName,
                        Page_Category: Tagging.OnHoldPageName
                    });
                    if (environment.env === ENV.demo) {
                        this._appState.updateCard(payload);
                        //return Observable.of('success');
                    }
                        return this.getShippingAndPayment();
                    
                }),
                catchError((e) => {
                    this.taggingErrorMessage(e, 'updateCard');
                    return Observable.throw(e);
                })
            );
    }

    getUpdatedCardPayload(formValue) {
        return {
            updateCreditCard: {
                ccExpiryYear: ('' + formValue.expiryYear % 100),
                ccExpiryMonth: '' + (formValue.expiryMonth > 9 ? formValue.expiryMonth : `0${formValue.expiryMonth}`),
                preferredIndicatorCode: '1',
                exclusiveToMember: 'NO',
                nickName: 'BLNK',
                electronicPaymentAccountID: formValue.ElectronicPaymentAccountID,
                source: 'QL'
            }
        };
    }

    initOnHoldDetailsAndShipping(): Observable<any> {
        return forkJoin([this.getOnHoldOrderDetails(), this.getShippingAndPayment()])
            .pipe(
                catchError((e) => {
                    console.log(e);
                    return Observable.of(e);
                })
            );
    }

    getBankAccountPayload(formValue, encrypted) {
        return {
            addECPAccount: {
                bankRoutingNumber: encrypted[1],
                bankAccountNumber: encrypted[0],
                bankAccountType: formValue.accountType,
                firstName: formValue.firstName,
                lastName: formValue.lastName,
                exclusiveToMember: 'NO',
                nickName: 'BLNK',
                preferredIndicatorCode: '1',
                source: 'QL'
            }
        };
    }

    addAccount(payload): Observable<any> {
        if (FASTConfig && FASTConfig.JoseEncryption) {
            const accountNumber$ = fromPromise(FASTConfig.JoseEncryption(payload.accountNumber))
                .pipe(catchError((e) => Observable.of(this.aesEncryption(payload.accountNumber))));
            const routingNumber$ = fromPromise(FASTConfig.JoseEncryption(payload.routingNumber))
                .pipe(catchError((e) => Observable.of(this.aesEncryption(payload.routingNumber))));

            return forkJoin(accountNumber$, routingNumber$)
                .pipe(
                    switchMap((encrypted) => {
                        console.log(encrypted);
                        return this.callAddAccountAPI(payload, encrypted);
                    })
                );
        } else {
            return this.callAddAccountAPI(payload, [this.aesEncryption(payload.accountNumber), this.aesEncryption(payload.routingNumber)]);
        }
    }

    callAddAccountAPI(payload, encrypted) {
        return this._http.post('addAccount', this.getBankAccountPayload(payload, encrypted)).pipe(
            switchMap(() => {
                this._analytics.view({
                    Page_Name: Tagging.AddElectronicAccount,
                    Page_Category: Tagging.OnHoldPageName
                });
                if (environment.env === ENV.demo) {
                    this._appState.addBank(payload);
                }
                return this.getShippingAndPayment();
            }),
            catchError((e) => {
                this.taggingErrorMessage(e, 'addAccount');
                return Observable.throw(e);
            })
        );
    }

  resolveOnHoldOrderIssues(payload): Observable<any> {
        return this._http.post('resolveOnHoldOrderIssues', Object.assign({}, payload, { ECCRCustomParams: [] }))
            .pipe(
                map((data) => data),
                catchError((error) => {
                    console.log(error);
                    return Observable.throw('error');
                })
            );
    }

    private getAddressPayload(payload) {
        return {
            request: {
                address1: {
                    __cdata: payload.address
                },
                address2: {
                    __cdata: ''
                },
                city: payload.city,
                state: payload.state,
                zipCode: payload.zipCode.substring(0, 5),
                zipSuffixCode: payload.zipCode.length > 5 ? payload.zipCode.slice(-4) : '0000'
            }
        };
    }

    validateAddress(payload): Observable<any> {
        return this._http.post('validateAddress', this.getAddressPayload(payload.address), {
            params: {
                id: 'validateAddress'
            }
        })
            .pipe(
                mergeMap((data: any) => {
                    if (has(data, 'header') && data.header.statusCode === '0000' && data.header.validationstatus === 'true') {
                        return this.multiplePlaceOrder(payload.selectedRx, false);
                    } else {
                        return Observable.throw(data);
                    }
                }),
                catchError((error) => {
                    console.log(error);
                    return Observable.throw(error);
                })

            );
    }

    refreshToken(): Observable<any> {
        return this._http.post('refreshToken', {})
            .pipe(
                map(data => data),
                catchError((error) => {
                    console.log(error);
                    return Observable.throw(error);
                })
            );
    }

    expireToken(): Observable<any> {
        return this._http.post('expireToken', {})
            .pipe(
                map(data => data),
                catchError((error) => {
                    console.log(error);
                    return Observable.throw(error);
                })
            );
    }

    private getFormattedTimeStamp(d: Date) {
        const year = d.getFullYear();
        const month = (d.getMonth() + 1) > 9 ? (d.getMonth() + 1) : '0' + (d.getMonth() + 1);
        const day = d.getDate() > 9 ? d.getDate() : '0' + d.getDate();
        const hours = d.getHours() > 9 ? d.getHours() : '0' + d.getHours();
        const mins = d.getMinutes() > 9 ? d.getMinutes() : '0' + d.getMinutes();
        const sec = d.getSeconds() > 9 ? d.getSeconds() : '0' + d.getSeconds();
        const milli = d.getMilliseconds();
        return `${year}-${month}-${day}-${hours}.${mins}.${sec}.${milli}`;
    }

    getSaveConsentPayload(payload) {
        return {
            request: {
                application: 'portal',
                beneficiaryKey: {
                    internalID: this._appState.getParticipantId()
                },
                sourceCode: 'DPT',
                requesterID: 'portal',
                orderConsents: payload.map(rx => {
                    return {
                        reasonCode: rx.reasonCode,
                        consentResponse: rx.isSelected ? 'Y' : 'N',
                        responseTimestamp: this.getFormattedTimeStamp(new Date()),
                        rxNumber: rx.rxNumber
                    };
                })
            }
        };
    }

    saveConsentResponse(payload): Observable<any> {
        return this._http.post('saveConsentResponse', payload, {
            params: {
                responseType: 'JSON',
                wfc: 'shipcon-3093'
            }
        })
        .pipe(
            catchError((error) => {
                return Observable.of('success');
            })
        );
    }

    multiplePlaceOrder(payload, isFromMEDD): Observable<any> {
        return this._http.post('getRefills', {})
            .pipe(
                flatMap(() => {
                    return this._http.post('multiplePlaceOrder', Object.assign({},
                        this._appState.getMultiplePlaceOrderPayload(payload, isFromMEDD)), {
                        params: {
                            componentId: 'FASTDigitalOrder',
                            fastIndicator: 'YES',
                            id: 'multiplePlaceOrder',
                            xmlFormat: 'True'
                        }
                    }).pipe(
                        switchMap(data => {
                            if (isFromMEDD) {
                                const saveConsentPayload = this.getSaveConsentPayload(payload);
                                return this.saveConsentResponse(saveConsentPayload);
                            } else {
                                const resolveOrderPayload = this._appState.getResolveOnHoldPayload(payload, RELEASE_STATUS.RELEASED);
                                return this.resolveOnHoldOrderIssues(resolveOrderPayload)
                                    .pipe(
                                        catchError((error) => {
                                            console.log(error);
                                            return Observable.of(error);
                                        })
                                    )
                            }
                        })                        
                    );
                }),
                catchError((error) => {
                    console.log(error);
                    return Observable.throw(error);
                })
            );
    }

}
