import { Injectable } from '@angular/core';
import { Utils } from '../utils';
import { environment } from '../../../environments/environment';
import { HttpClient, HttpParams } from '@angular/common/http';


export enum INTERACTION_STATUS {
  COMPLETED = 'Completed',
  FAILED = 'Fail'
}

export enum INTERACTION_TYPE {
  RELEASE_ORDER = '3219',
}

@Injectable()
export class EccrService {
  private readonly _interaction = {
    sessionID: 'sessionID',
    sourceInteractionId: '',
    channelType: Utils.channelType,
    systemID: Utils.getSystemId(environment),
    clientChannelID: environment.ipAddress, // FAST Server IP Addresses.
    corporateChannelID: 'DIGITAL_ORDER_RELEASE', // Portal friendly URL
    sessionStartTime: '',
    sessionEndTime: '',
    sessionInitiatior: 'Consumer',
    memberPartyIdLevel_01: '',
    memberPartyIdLevel_02: '',
    memberPartyIdLevel_03: '',
    memberPartyIdLevel_04: '',
    memberPartyIdLevel_05: '',
    memberPartySourceID: 'QL',
    sessionInitStatus: 'Auth',
    serviceID: '',
    interactionType: '', // Dynamic Value based on interaction
    interactionStartTimestamp: '',
    interactionEndTimestamp: '',
    interactionResult: '',
    agentID: ' ',
    customerExperienceType: ' ',
    memberPartyRelationship: ' ',
    updatedTimestamp: ' ',
    sessionInitParty: ' ',
    transInteraction: {},
    memberInteraction: {}
  };

  private readonly _additionalData = [{
    key: 'COMPONENT_ID',
    value: 'DigitalOrderRelease'
  }, {
    key: 'FAST_INDICATOR',
    value: 'YES'
  }, {
    key: 'FAST_STYLE',
    value: environment.faststyle
  }];

  constructor(private _http: HttpClient) {}

  log(type: INTERACTION_TYPE, status: INTERACTION_STATUS, sessionID, additionalData = []) {
    const interactionData = this._additionalData;
    // additionalData.map(data => {
    //   interactionData.push(data)
    // });
    let httpParams = new HttpParams();
    httpParams = httpParams.append('contentType', 'json');
    return this._http.post('eccrURL', {
      interaction: {
        ...this._interaction,
        interactionEndTimestamp: Utils.fortmatDateTime(new Date(), 'dd-MMM-yyyy h:mm:ss TT'),
        interactionResult: status,
        interactionType: type,
        sessionID: sessionID,
        sourceInteractionId: Utils.guid,
        interactionData: {
          additional_data: interactionData
        }
      }
    },
    {
      params: httpParams
    }).subscribe();
  }
}
