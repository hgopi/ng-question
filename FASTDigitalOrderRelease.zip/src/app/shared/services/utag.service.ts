import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { ENV, ENV_MODE } from '../enum';
import { Utils } from '../utils';

@Injectable()
export class TealiumUtagService {
  private static deviceType = Utils.getUserAgent();
  private static channelName = TealiumUtagService.deviceType === 'DESKTOP' ? 'DESKTOP' : 'MOBILE WEB';
  private static platform = environment.mode === ENV_MODE.MAPP ? 'mapp' : ((TealiumUtagService.deviceType === 'DESKTOP') ? 'dweb' :
    ((TealiumUtagService.deviceType.indexOf('MOBILE') !== -1) ? 'mweb' :
      (TealiumUtagService.deviceType.indexOf('TAB') !== -1) ? 'tweb' : 'dweb'));

  private static getEST(): string {
    const utc = new Date().getTime() + (new Date().getTimezoneOffset() * 60000);
    const tempDate = new Date();
    const jan = new Date(tempDate.getFullYear(), 0, 1);
    const jul = new Date(tempDate.getFullYear(), 6, 1);

    if (Math.min(jan.getTimezoneOffset(), jul.getTimezoneOffset()) === tempDate.getTimezoneOffset()) {
      return new Date(utc + (3600000 * -4)).toLocaleString() + ' EST';
    } else {
      return new Date(utc + (3600000 * -5)).toLocaleString() + ' EST';
    }

  }

  private static getPreviouspageName(): string {
    if ((<any>window).utag && (<any>window).utag.data && (<any>window).utag.data.Page_Name) {
      return 'pbm' + '|' + this.platform  + '|' + (<any>window).utag.data.Page_Name;
    }  else {
      return '';
    }
  }
  private static getPreviouspageURL(): string {
    if ((<any>window).utag && (<any>window).utag.data && (<any>window).utag.data.page_url) {
      return (<any>window).utag.data.page_url;
    } else {
      return '';
    }
  }
  private static getEnv(Tealium_URL) {
    const separator = '/';
    if (Tealium_URL != null) {
      const splitedArray = Tealium_URL.split(separator);
      if (splitedArray.length > 2) {
        return splitedArray[splitedArray.length - 2];
      }
    }
    return null;
  }

  private static _getBasicTraffic(): any {
    const common_url = 'pbm';
    const page_category = 'manage profile';
    const page_name = 'communication preferences';
    const basicViewTags = {
      domain: window.document.domain,
      adobe_platform: this.platform,
      // member_id: MemberInfoService.config.externalID.trim(),
      common_url: common_url,
      Page_Name : 'communication preferences',
      Page_Category: page_category,
      sub_section1: common_url + '|' + this.platform + '|' + page_category,
      sub_section2: common_url + '|' + this.platform + '|' + page_category,
      sub_section3: common_url + '|' + this.platform + '|' + page_category,
      sub_section4: common_url + '|' + this.platform + '|' + page_category,
      adobe_page_name: common_url + '|' + this.platform + '|' + page_name,
      previous_adobe_page_name: this.getPreviouspageName(),
      page_url: window.location.host + window.location.pathname,
      previous_page_url: this.getPreviouspageURL(),
      responsive_design: this.platform,
      authentication_state: 'Rx Registered',
      state_logged_in: 'true',
      environment: this.getEnv(environment.tealiumURL),
      time_stamp: this.getEST(),
      document_title: document.title
    };
    return basicViewTags;
  }
  private static _getUtagData(): any {
    const utagData = {
      environment : this.getEnv(environment.tealiumURL),
      site_name : ((environment.faststyle === 'caremark') ?  'FASTINT' : ('FAST ' + environment.faststyle)),
      country: 'US',
      language: 'EN',
      currency: 'USD',
      platform: this.platform,
    //   Client_Id: MemberInfoService.config.clientId,
    //   PBM_Client_Name: MemberInfoService.config.clientName
    };
    return utagData;
  }
  getScript(src: string, callback: Function) {
    const d = document;
    const o = {
      callback: callback || function () {
      }
    };
    let s, t;

    if (typeof src === 'undefined') {
      return;
    }
    s = d.createElement('script');
    s.language = 'javascript';
    s.type = 'text/javascript';
    s.async = 1;
    s.charset = 'utf-8';
    s.src = src;
    if (typeof o.callback === 'function') {
      if (d.addEventListener) {
        s.addEventListener('load', function () {
          o.callback();
        }, false);
      } else {
        // old IE support
        s.onreadystatechange = function () {
          if (this.readyState === 'complete' || this.readyState === 'loaded') {
            this.onreadystatechange = null;
            o.callback();
          }
        };
      }
    }
    t = d.getElementsByTagName('script')[0];
    t.parentNode.insertBefore(s, t);
  }

  track(tealium_event: string, data?: any) {
    if ((<any>window).utag === undefined) {
      this.getScript(environment.tealiumURL, function () {
        (<any>window).utag.track(tealium_event, data);
      });
    } else {
      (<any>window).utag.track(tealium_event, data);
    }
  }

  view(data?: any) {
    const viewData = Object.assign({}, TealiumUtagService._getUtagData(), TealiumUtagService._getBasicTraffic(), data);
    // console.log('utag > view > ', JSON.stringify(viewData));
    this.track('view', viewData);
  }

  link(data?: any) {
    const linkData = Object.assign({}, TealiumUtagService._getUtagData(), data);
    // console.log('utag > link > ', JSON.stringify(linkData));
    this.track('link', linkData);
  }

}
