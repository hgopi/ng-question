import { environment } from '../../../environments/environment';
import * as xml2js from 'xml2js';
import { HttpParams, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { has, merge } from 'lodash-es';
import { VERSION, ENV } from '../enum';
import { IServiceInfo } from '../models/config';
import * as X2JS from 'x2js';

export abstract class HttpParser {

  private _defaultConfig: IServiceInfo = {
    xmlFormat: false,
    version: VERSION.V2
  };

  private _parser = new xml2js.Parser({ explicitArray: false });
  private _builder = new xml2js.Builder({ headless: true });
  private x2js  = new X2JS();

  static get isDemoEnv() {
    return environment.env === ENV.demo;
  }

  protected getUrl(service: IServiceInfo) {
    const url = `${environment.baseUrl}${service.endpoint}`;
    return HttpParser.isDemoEnv ? url + '?t=' + Date.now() : url;
  }

  protected getResponseType(service: IServiceInfo) {
    return service.xmlFormat ? 'text' : 'json';
  }

  protected getParam(key: string, service: IServiceInfo, existing: HttpParams) {
    let version = service.paramVersion || environment.version;
    // if (service.serviceName === 'addCreditCardPaymentAccount') {
    //     version = '2.0';
    // }
    // if (service.serviceName === 'multiplePlaceOrder') {
    //   version = '3.0';
    // }
    const data = {
      'apiKey': environment.serviceUID,
      'apiSecret': environment.serviceSALT,
      'appName': key === 'eccrURL' ? 'PORTAL' : environment.appName,
      'channelName': environment.channelName,
      'deviceID': environment.deviceID,
      'deviceToken': environment.deviceToken,
      'deviceType': environment.deviceType,
      'lineOfBusiness': environment.lineOfBusiness,
      'serviceCORS': environment.serviceCORS,
      'version': version,
      'tokenID': environment.tokenID,
      'serviceName': service.serviceName,
    };
    if (service.operationName) {
      data['operationName'] = service.operationName;
      data['xmlformat'] = environment.xmlformat;
    } else if (service.operation) {
      data['operation'] = service.operation;
    }
    let httpParams = new HttpParams({ fromObject: data });
    existing.keys().forEach(function (prop) {
      httpParams = httpParams.append(prop, existing.get(prop));
    });
    return httpParams;
  }

  protected init(serviceName: string) {
    if (has(environment.services, serviceName)) {
      return {
        key: serviceName,
        service: Object.assign({}, this._defaultConfig, environment.services[serviceName])
      };
    }
  }

  private _isSuccess(data, responseKey) {
    return has(data, responseKey + '.header.statusCode') && data[responseKey].header.statusCode === '0000';
  }

  private _returnError(data, responseKey) {
    throw new HttpErrorResponse({
      error:  has(data, responseKey) ? data[responseKey] : 'Unable to process the response',
      status: has(data, responseKey + '.header.statusCode') ? data[responseKey].header.statusCode : '',
      statusText: has(data, responseKey + '.header.statusDesc') ? data[responseKey].header.statusDesc : ''
    });
  }

  private _getNewResponse(res, result) {
    return new HttpResponse({
      body: result,
      headers: res.headers,
      status: res.status,
      statusText: res.statusText,
      url: res.url
    });
  }

  protected handleResponse(res, key: string, service: IServiceInfo) {
    if (res instanceof HttpResponse) {
      const responseKey = this._getResponseKey(key, service);
      let result: any;
      if (service.xmlFormat) {
        this._parser.parseString(res.body, (error, res1) => {
          result = res1;
        });
      } else {
        result = res.body;
      }
      if (this._isSuccess(result, responseKey)) {
        // return service.xmlFormat ? this.getNewResponse(res, result) : res;
        return this._getNewResponse(res,
          service.fullResponse ? result[responseKey] : result[responseKey].detail || result[responseKey].details || result[responseKey]
        );
      } else {
        this._returnError(result, responseKey);
      }
    }
    return res;
  }

  private _getResponseKey(key: string, service: IServiceInfo) {
    return service.responseHeader ? service.responseHeader : service.version === VERSION.V1 ? 'response' : key + 'Response';
  }

  protected getMethod(method) {
    return HttpParser.isDemoEnv ? 'GET' : method;
  }

  protected getPayload(payload, key, service = null) {
    let tokenID;
    if (has(payload, 'tokenID')) {
      tokenID = payload.tokenID;
      delete payload.tokenID;
    }
    const request = {
      [key + 'Request']: {
        header: merge({}, {
          serviceContext: {
            appName: key === 'eccrURL' ? 'PORTAL' : environment.appName,
            lineOfBusiness: environment.lineOfBusiness,
            channelName: environment.channelName,
            tokenID: tokenID || environment.tokenID,
            deviceID: environment.deviceID,
            deviceType: environment.deviceType,
            deviceToken: environment.deviceToken,
            responseFormat: 'JSON',
            tokenType: 'PBMMEM'
          },
          securityContext: {
            securityType: 'apiKey',
            apiKey: environment.serviceUID
          }
        }, payload.ECCRCustomParams ? this._getECCR(payload, tokenID) : {}),
        details: payload && payload.requestBody || payload
      }
    };
    console.log('Payload for key' + key);
    if (key === 'addAccount') {
      delete request.addAccountRequest.header.serviceContext.responseFormat;
      delete request.addAccountRequest.header.securityContext.securityType;
    }
    if (key === 'updateCard') {
      delete request.updateCardRequest.header.serviceContext.responseFormat;
      delete request.updateCardRequest.header.securityContext.securityType;
    }
    return service.xmlFormat ? this._builder.buildObject(request) : request;
  }

  private _getECCR(data: any, isFromGuest) {
    const base = [
      {
        key: 'HOST_ID',
        value: '16527' // '20442'
      },
      {
        key: 'COMPONENT_ID',
        value: 'ResolveOrder'
      },
      {
        key: 'FAST_INDICATOR',
        value: 'YES'
      },
      {
        key: 'FAST_STYLE',
        value: 'caremark'
      }
    ];
    data.ECCRCustomParams.map(eachECCR => base.push(eachECCR));
    delete data.ECCRCustomParams;
    return { ECCRCustomParams: base };
  }

  protected getMultiplePlaceOrderPayload(payload) {
    const request = {
      'request': {
        header: this._getECCR( { ECCRCustomParams: [] }, false),
        ...payload
      }
    };
    return this.x2js.js2xml(request);
    // return this._builder.buildObject(request);
  }

  protected getRefillsPayload(payload) {
    const request = {
      request: {
        header: {
          serviceContext: {
            lineOfBusiness: environment.lineOfBusiness || 'PBM',
            tokenID: environment.tokenID,
            appName: environment.appName || 'CMK_WEB',
            channelName: environment.channelName || 'WEB',
            deviceID: environment.deviceID,
            deviceToken: environment.deviceToken,
            deviceType: environment.deviceType
          },
          securityContext: {
            apiKey: environment.serviceUID
          }
        },
        details: {
          wfc: 'GR',
          xmlFormat: 'True',
          estimatedCost: 2,
          familyRefills: 'True'
        }
      }
    };
    return this.x2js.js2xml(request);
  }

  protected getFormattedPayload(payload, service) {
    if (!payload || service.serviceName === 'addCreditCardPaymentAccount' ||
      service.serviceName === 'multiplePlaceOrder' || service.serviceName === 'getRefills' || !service.xmlFormat) {
      return payload;
    }
    if (service.serviceName === 'validateAddress') {
      return this.x2js.js2xml(payload);
    }
    return this._builder.buildObject(payload);
  }

}
