import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import { HttpParser } from './http-parser';
import { VERSION } from '../enum';


@Injectable()
export class EnvInterceptor extends HttpParser implements HttpInterceptor {

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const config = this.init(req.url);
    let payload = req.body;
    if (config && config.service && config.service.version === VERSION.V1) {
      if (config.service.serviceName === 'multiplePlaceOrder') {
        payload = this.getMultiplePlaceOrderPayload(req.body);
      }
      const apiReq = req.clone({
        method : this.getMethod(req.method),
        url: this.getUrl(config.service),
        body: this.getFormattedPayload(payload, config.service),
        params: this.getParam(config.key, config.service, req.params),
        setHeaders: {
          'Accept': 'application/json, text/plain, application/xml',
          'Content-Type': 'application/json, application/xml',
        },
        responseType: this.getResponseType(config.service)
      });
      console.log(`/------Request Payload for ${config.service.serviceName} ------/`, payload);
      return next.handle(apiReq)
        .pipe(
          map(res => this.handleResponse(res, config.key, config.service)),
          catchError((e) => {
            console.log(e);
            throw e;
          })
        );
    }
    return next.handle(req);
  }
}
