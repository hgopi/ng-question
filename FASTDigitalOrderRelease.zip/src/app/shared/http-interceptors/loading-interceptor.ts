import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { finalize } from 'rxjs/operators';
import { LoaderService } from './../components/loader';

@Injectable()
export class LoadingInterceptor implements HttpInterceptor {

  private loaderTextUrls = ['addCreditCard', 'updateCard', 'addAccount'];

  constructor(private loader: LoaderService) { }


  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    this.loader.show(this.loaderTextUrls.indexOf(req.url) > -1);
    return next.handle(req).pipe(
      finalize(() => {
        this.loader.hide();
      })
    );
  }

}
