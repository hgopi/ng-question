import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { map, catchError } from 'rxjs/operators';
import { VERSION } from '../enum';
import { HttpParser } from './http-parser';

@Injectable()
export class NewServiceInterceptor extends HttpParser implements HttpInterceptor {

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<any> {
    const config = this.init(req.url);
    if (config && config.service && config.service.version === VERSION.V2) {
      let payload = this.getPayload(req.body, config.key, config.service);
      if (config.service.serviceName === 'getRefills') {
        payload = this.getRefillsPayload(req.body);
      }
      console.log(`/------Request Payload for ${config.key} ------/`, payload);
      let acceptHeader = 'application/json';
      let acceptContent = 'application/json';
      if (config.service.acceptHeader === 'XML') { acceptHeader = 'application/xml';  }
      if (config.service.acceptContent === 'XML') { acceptContent = 'application/xml';  }
      const apiReq = req.clone({
        method : this.getMethod(req.method),
        url: this.getUrl(config.service),
        body: payload,
        setHeaders: {
          'Accept': acceptHeader,
          'Content-Type': acceptContent,
        },
        responseType: this.getResponseType(config.service)
      });
      return next.handle(apiReq)
        .pipe(
          map(res => this.handleResponse(res, config.key, config.service)),
          catchError((e) => {
            console.log(e);
            throw e;
          })
        );
    }
    return next.handle(req);
  }

}
