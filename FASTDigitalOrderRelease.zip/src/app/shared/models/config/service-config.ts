import { IServiceInfo } from './service-info';

/**
 * Services used throught the application and their information
 * (i.e) enpoints, operationName, version etc
 */
export interface IServiceConfig {
    getOnHoldOrderDetails: IServiceInfo;
    getShippingAndPayment: IServiceInfo;
    addCreditCard: IServiceInfo;
    updateCard: IServiceInfo;
    addAccount: IServiceInfo;
    resolveOnHoldOrderIssues: IServiceInfo;
    expireToken: IServiceInfo;
    refreshToken: IServiceInfo;
    eccrURL: IServiceInfo;
    multiplePlaceOrder: IServiceInfo;
}
