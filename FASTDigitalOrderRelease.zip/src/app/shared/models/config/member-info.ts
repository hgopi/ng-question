export interface IMemberInfo {
    userID ?:  string;
    pznID ?:  string;
    accountID ?:  string;
    benefactorClientInternalID ?:  string;
    cardholderInternalID ?:  string;
    carrierID ?:  string;
    groupID ?:  string;
    eisName ?:  string;
    externalID ?:  string;
    personCode ?:  string;
    memberPartyIndentifier ?:  string;
    sessionID ?:  string;
    corporateChannelID ?:  string;
  }
