import { VERSION } from '../../enum';

/**
 * Service Information for each services used
 */
export interface IServiceInfo {
    serviceName?: string;
    endpoint?: string;
    operationName?: string;
    operation?: string;
    xmlFormat?: boolean;
    version?: VERSION;
    fullResponse?: boolean;
    paramVersion?: string;
    acceptHeader?: string;
    acceptContent?: string;
    responseHeader?: string;
}
