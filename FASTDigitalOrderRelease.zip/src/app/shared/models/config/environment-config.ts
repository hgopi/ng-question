import { ENV, ENV_MODE } from '../../enum';
import { IServiceConfig } from './service-config';

/**
 * Base configuration attributes that are required for service implementation
 */
export interface IEnvironmentConfig {
    env ?: ENV;
    production?: boolean;
    faststyle ?: string;
    baseUrl?: string;
    serviceUID?: string;
    serviceSALT?: string;
    appName?: string;
    channelName?: string;
    deviceID?: string;
    deviceToken?: string;
    deviceType?: string;
    lineOfBusiness?: string;
    serviceCORS?: string;
    version?: string;
    tokenID?: string;
    xmlformat?: string;
    services?: IServiceConfig;
    ipAddress?: string;
    xid?: string;
    tealiumURL ?: string;
    eccrURL?: string;
    mode?: ENV_MODE;
    cms?: any;
    orderNo?: string;
    isRegistered?: string;
    reasonCode?: string;
    alertType?: string;
    regStatus?: string;
    timeoutURL?: string;
    landingPageURL?: string;
    workFlowContext?: string;
    webTrendsMsgId?: string;
    ccExpiredDateFactor?: number;
}
