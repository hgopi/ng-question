const CONSENT_TO_PAY  = [51, 52, 53];
const INDEFINITE_HOLD = [13, 27, 31, 32];
const PAYMENT_ALERT   = [54];
const CONSENT_SHIP    = [11];
const EXCLUSION       = [11, 13, 27, 31, 32];

export const ReasonCodes = {
    consentToPay: {
        checkWith       : CONSENT_TO_PAY,
        exclude         : EXCLUSION,
        displayRx       : CONSENT_TO_PAY,
        reasonCode      : 1
    },
    paymentAlert: {
        checkWith       : PAYMENT_ALERT,
        exclude         : EXCLUSION,
        displayRx       : [ ],
        reasonCode      : 2
    },
    indefiniteHold: {
        checkWith       : INDEFINITE_HOLD,
        exclude         : [ ],
        displayRx       : INDEFINITE_HOLD,
        reasonCode      : 4
    },
    consentShip: {
        checkWith       : CONSENT_SHIP,
        exclude         : [ ],
        displayRx       : CONSENT_SHIP,
        reasonCode      : 3
    }
};
