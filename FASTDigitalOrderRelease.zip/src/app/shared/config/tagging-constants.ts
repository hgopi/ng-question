export const Tagging = {
    OnHoldPageName: 'release on hold status',
    OnHoldPageCategory: 'On hold prescriptions',
    AddCreditCardPageName: 'guest add credit card',
    AddElectronicAccount: 'guest add electronic check',
    CancelOrderConfirmation: 'cancel order confirmation modal',
    CancelOnHoldSubmit: 'on hold cancelled',
    CancelOnHoldLink: 'Custom: Order cancelled',
    ConfirmationPageLoad: 'release on hold confirmation',
    OnHoldSubmit: 'on hold submitted',
    OnHoldSubmitLink: 'Custom: on hold submitted',
    ReviewOrderPage: 'release on hold review',
    ReviewOrderPageCategory: 'On hold prescriptions'
};
