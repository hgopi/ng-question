export const CMSConstants = {
    cvsCaremarkLogoMobile: 'FASTMobileLogoSpot',
    utilityFooterMobile: 'FASTMobileUtilityFooterSpot',
    cvsCaremarkLogo: 'FASTCVSCaremarkLogoSpot',
    utilityFooter: 'FASTUtilityFooterSpot',
    maxAttempt: 'DigitalOrderReleaseMaxAttemptsSpot',
    indefiniteHoldDisclaimer: 'DigitalOrderReleaseIndefHoldDisclaimerSpot',
    medDHeader: 'DigitalOrderReleaseMedDShipConsentSpot'
};
