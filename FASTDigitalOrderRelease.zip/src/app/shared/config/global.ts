import { IEnvironmentConfig, IServiceConfig } from '../models/config';
import { ENV, ENV_MODE, VERSION } from '../enum';
import { Utils } from '../utils';

const userAgent = Utils.getUserAgent();
/**
 * Global configuration object with defaults and enviroments specific
 * Values in default can be over written by updating the same property in required environment
 * Defaults will have configuration for prod environment
 */
export const globalConfig = {
    prod: <IEnvironmentConfig>{
    },
    demo: <IEnvironmentConfig>{
        env: ENV.demo,
        production: false,
        baseUrl: 'assets/data/',
        services: <IServiceConfig>{
            getOnHoldOrderDetails: {
                endpoint: 'getOnHoldOrderDetails.json'
            },
            getShippingAndPayment: {
                endpoint: 'getShippingandPayment.xml'
            },
            addCreditCard: {
                endpoint: 'addCreditCard.xml'
            },
            updateCard: {
                endpoint: 'updateCard.xml'
            },
            addAccount: {
                endpoint: 'addAccount.xml'
            },
            resolveOnHoldOrderIssues: {
                endpoint: 'resolveOnHoldOrderIssues.json'
            },
            expireToken: {
                endpoint: 'expireToken.xml'
            },
            refreshToken: {
                endpoint: 'refreshToken.xml'
            },
            eccrURL: {
                endpoint: 'eccr.xml'
            },
            validateAddress: {
                endpoint: 'validateAddress.xml'
            },
            multiplePlaceOrder: {
                endpoint: 'multiplePlaceOrder.xml'
            },
            saveConsentResponse: {
                endpoint: 'saveConsentResponse.json'
            },
            getRefills: {
                endpoint: 'getRefills.xml'
            }
        }
    },
    stp: <IEnvironmentConfig>{
        env: ENV.stp,
        production: true,
        baseUrl: 'https://stpservices.caremark.com:11101/',
        serviceUID: '1008347202313004A50F01F33D27EAB1',
        serviceSALT: 'E228F4CF4BE33EA5A20FE5FF9D5573F8',
        tealiumURL: 'https://tags.tiqcdn.com/utag/cvs/fast/stp/utag.js',
        eccrURL: 'https://stpservices.caremark.com:11422/',
        timeoutURL: 'https://stpv8ptlint.caremark.com/wps/portal/'
    },
    cte: <IEnvironmentConfig>{
        env: ENV.cte,
        production: true,
        baseUrl: 'https://ctepbmservices.caremark.com/',
        serviceUID: '769c71df-fd85-4645-92e0-b8003a8a4ef3',
        serviceSALT: '764588f5-551e-4894-b401-13ad2d61c1cf',
        tealiumURL: 'https://tags.tiqcdn.com/utag/cvs/fast/cte/utag.js',
        eccrURL: 'https://ctepbmservices.caremark.com/',
        timeoutURL: 'https://ctev8ptlint.caremark.com/wps/portal/'
    },
    sit1: <IEnvironmentConfig>{
        env: ENV.sit1,
        production: false,
        baseUrl: 'https://sit1pbmservices.caremark.com/',
        serviceUID: '769c71df-fd85-4645-92e0-b8003a8a4ef3',
        serviceSALT: '764588f5-551e-4894-b401-13ad2d61c1cf',
        tealiumURL: '//tags.tiqcdn.com/utag/cvs/fast/sit1/utag.js',
        eccrURL: 'https://sit1pbmservices.caremark.com/',
        timeoutURL: 'https://sit1v8ptlint.caremark.com/wps/portal/'
    },
    sit2: <IEnvironmentConfig>{
        env: ENV.sit2,
        production: false,
        baseUrl: 'https://sit2pbmservices.caremark.com/',
        serviceUID: '769c71df-fd85-4645-92e0-b8003a8a4ef3',
        serviceSALT: '764588f5-551e-4894-b401-13ad2d61c1cf',
        tealiumURL: '//tags.tiqcdn.com/utag/cvs/fast/sit2/utag.js',
        eccrURL: 'https://sit2pbmservices.caremark.com/',
        timeoutURL: 'https://sit2v8ptlint.caremark.com/wps/portal/'
    },
    sit3: <IEnvironmentConfig>{
        env: ENV.sit3,
        production: false,
        baseUrl: 'https://sit3pbmservices.caremark.com/',
        serviceUID: '769c71df-fd85-4645-92e0-b8003a8a4ef3',
        serviceSALT: '764588f5-551e-4894-b401-13ad2d61c1cf',
        tealiumURL: '//tags.tiqcdn.com/utag/cvs/fast/sit3/utag.js',
        eccrURL: 'https://sit3pbmservices.caremark.com/',
        timeoutURL: 'https://sit3v8ptlint.caremark.com/wps/portal/'
    },
    dev1: <IEnvironmentConfig>{
        env: ENV.dev1,
        production: false,
        baseUrl: 'https://devservices-west.caremark.com:11101/',
        serviceUID: '769c71df-fd85-4645-92e0-b8003a8a4ef3',
        serviceSALT: '764588f5-551e-4894-b401-13ad2d61c1cf',
        tealiumURL: '//tags.tiqcdn.com/utag/cvs/fast/dev1/utag.js',
        eccrURL: 'https://pbmservices.caremark.com/',
        timeoutURL: 'https://dev1v8ptlint.caremark.com/wps/portal/'
    },
    dev2: <IEnvironmentConfig>{
        env: ENV.dev2,
        production: false,
        baseUrl: 'https://devservices-west.caremark.com:11102/',
        serviceUID: '769c71df-fd85-4645-92e0-b8003a8a4ef3',
        serviceSALT: '764588f5-551e-4894-b401-13ad2d61c1cf',
        tealiumURL: 'https://tags.tiqcdn.com/utag/cvs/fast/dev2/utag.js',
        eccrURL: 'https://devservices.caremark.com:11442/',
        timeoutURL: 'https://dev2v8ptlint.caremark.com/wps/portal/'
    },
    dev3: <IEnvironmentConfig>{
        env: ENV.dev3,
        production: false,
        baseUrl: 'https://devservices-west.caremark.com:11103/',
        serviceUID: '769c71df-fd85-4645-92e0-b8003a8a4ef3',
        serviceSALT: '764588f5-551e-4894-b401-13ad2d61c1cf',
        tealiumURL: 'https://tags.tiqcdn.com/utag/cvs/fast/dev3/utag.js',
        eccrURL: 'https://devservices.caremark.com:11462/',
        timeoutURL: 'https://dev3v8ptlint.caremark.com/wps/portal/'
    },
    defaults: <IEnvironmentConfig>{
        env: ENV.prod,
        production: true,
        faststyle: 'caremark',
        baseUrl: 'https://pbmservices.caremark.com/',
        serviceUID: 'a2ff75c6-2da7-4299-929d-d670d827ab4a',
        serviceSALT: 'a8df2d6e-b11c-4b73-8bd3-71afc2515dae',
        appName: 'CMK_WEB',
        channelName: userAgent === 'DESKTOP' ? 'WEB' : 'MOBILE',
        deviceID: 'device12345',
        deviceToken: 'device12345',
        deviceType: userAgent,
        lineOfBusiness: 'PBM',
        serviceCORS: 'TRUE',
        version: '1.0',
        tokenID: '72886BAFB60F392997E6881B95C6F39F',
        xmlformat: 'False',
        mode: ENV_MODE.STANDALONE,
        tealiumURL: '//tags.tiqcdn.com/utag/cvs/fast/prod/utag.js',
        eccrURL: 'https://pbmservices.caremark.com/',
        timeoutURL: 'https://www.caremark.com/wps/portal/',
        ccExpiredDateFactor: 3,
        services: <IServiceConfig>{
            getOnHoldOrderDetails: {
                serviceName: 'getOnHoldOrderDetails',
                endpoint: 'PBMAGPv1/order/getOnHoldOrderDetails/V1',
                xmlFormat: false,
                version: VERSION.V2,
                fullResponse: true
            },
            getShippingAndPayment: {
                serviceName: 'getShippingAndPayment',
                endpoint: 'refill/getShippingAndPayment',
                xmlFormat: true,
                version: VERSION.V1
            },
            addCreditCard: {
                serviceName: 'addCreditCardPaymentAccount',
                endpoint: 'refill/addCreditCard',
                xmlFormat: true,
                version: VERSION.V1,
                paramVersion: '2.0'
            },
            updateCard: {
                serviceName: 'updateCard',
                endpoint: 'caremark/creditCard/updateCard/V1',
                xmlFormat: true,
                acceptHeader: 'XML',
                acceptContent: 'XML',
                version: VERSION.V2
            },
            addAccount: {
                serviceName: 'addAccount',
                endpoint: 'caremark/bankAccount/addAccount/V1',
                xmlFormat: true,
                acceptHeader: 'XML',
                acceptContent: 'XML',
                version: VERSION.V2
            },
            resolveOnHoldOrderIssues: {
                serviceName: 'resolveOnHoldOrderIssues',
                endpoint: 'PBMAGPv1/order/resolveOnHoldOrderIssues/V1',
                xmlFormat: false,
                version: VERSION.V2
            },
            expireToken: {
                serviceName: 'expireToken',
                endpoint: 'refill/expireToken',
                xmlFormat: true,
                version: VERSION.V1
            },
            refreshToken: {
                serviceName: 'refreshToken',
                endpoint: 'refill/refreshToken',
                xmlFormat: true,
                version: VERSION.V1,
                paramVersion: '2.0'
            },
            eccrURL: {
                serviceName: 'logInteractionEventExternal',
                endpoint: 'eccr/logInteractionEventExternal',
                version: VERSION.V1
            },
            validateAddress: {
                serviceName: 'validateAddress',
                endpoint: 'address/validateAddress',
                xmlFormat: true,
                acceptHeader: 'XML',
                acceptContent: 'XML',
                version: VERSION.V1
            },
            multiplePlaceOrder: {
                serviceName: 'multiplePlaceOrder',
                endpoint: 'refill/multiplePlaceOrder',
                xmlFormat: true,
                version: VERSION.V1,
                paramVersion: '3.0'
            },
            saveConsentResponse: {
                serviceName: 'saveConsentResponse',
                endpoint: 'refill/saveConsentResponse',
                xmlFormat: false,
                version: VERSION.V1
            },
            getRefills: {
                serviceName: 'getRefills',
                endpoint: 'caremark/refill/getRefills/V2',
                xmlFormat: true,
                version: VERSION.V2,
                acceptHeader: 'XML',
                acceptContent: 'XML',
                paramVersion: '1.0',
                responseHeader: 'response'
            }
        },
        cms: {},
        reasonCode: ''
    }
};
