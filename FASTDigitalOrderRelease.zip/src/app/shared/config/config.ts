import { Utils } from '../utils';
import { ENV_MODE, ENV } from '../enum';
import { has, merge } from 'lodash-es';
import { globalConfig } from './global';
import { IEnvironmentConfig } from '../models/config';
/**
 * To declare the native method exposed in mobile app alone for typescript compilation
 */
declare let native: any;

/**
 * To set the configuration based on the environment
 * Usually called only once from the environments used in build for initialization
 * After initialization default angular implementation can be used by accessing environment const
 */
export class Configuration {
    private static _env;
    private static readonly _config: IEnvironmentConfig = globalConfig.defaults;
    private static _override: IEnvironmentConfig = {};
    static config: IEnvironmentConfig = {};

    /**
     * To evaluvate the mode is native (i.e) Mobile App environment
     * If yes the retrives value via nativebridge methods
     * and overwrite with query param if any
     * else calls portalJson method to proceed
     */
    private static native() {
        /**
         * native object will be available only when emulated in mobile app
         * Else exception will be thrown if accessed in other environment
         */
        try {
            this.env = native.getConfigEnv();
            this._override = {
                mode: ENV_MODE.MAPP,
                tokenID: native.getToken(),
                appName: 'CMK_APP'
            };
            // overrides with query param if any
            this.query();
        } catch (e) {
            // calls portalJson
            this.portalJson();
        }
    }

    /**
     * To evaluvate the mode in which the application is build
     * If portalJson it is done by window.parent Object
     */
    private static portalJson() {
        /**
         * try if portalJSON value is accessible, because window.parent won't throw error.
         * but accessing any data will throw.
         */
        const portalJson = Utils.isInIframe() && window.parent && window.parent['FAST_INPUT_DATA'];
        if (portalJson) {
            this._override = <IEnvironmentConfig>{
                mode: ENV_MODE.PORTAL
            };
            if (portalJson.API_PARAM_DATA) {
                this.env = portalJson.API_PARAM_DATA.env;
                this._override.tokenID = portalJson.API_PARAM_DATA.tokenId || this._config.tokenID;
                this._override.serviceUID = portalJson.API_PARAM_DATA.apiKey || this._config.serviceUID;
                this._override.serviceSALT = portalJson.API_PARAM_DATA.apiSecret || this._config.serviceSALT;
                this._override.ipAddress = portalJson.API_PARAM_DATA.ipAddress || this._config.ipAddress;
                this._override.eccrURL = portalJson.API_PARAM_DATA.eccrURL || this._config.eccrURL;
            }
            if (portalJson.APP_PARAM_DATA) {
                this._override.xid = portalJson.APP_PARAM_DATA.xid || portalJson.APP_PARAM_DATA.XID || this._config.xid;
                this._override.orderNo = portalJson.APP_PARAM_DATA.orderNo;
                this._override.isRegistered = portalJson.APP_PARAM_DATA.isRegistered;
                this._override.alertType = portalJson.APP_PARAM_DATA.alertType;
                this._override.regStatus = portalJson.APP_PARAM_DATA.regStatus;
                this._override.timeoutURL = portalJson.APP_PARAM_DATA.timeoutURL;
                this._override.landingPageURL = portalJson.APP_PARAM_DATA.landingPageURL;
                this._override.workFlowContext = portalJson.APP_PARAM_DATA.workFlowContext;
                this._override.webTrendsMsgId = portalJson.APP_PARAM_DATA.webTrendsMsgId;
                if (portalJson.APP_PARAM_DATA.ccExpiredDateFactor) {
                    this._override.ccExpiredDateFactor = parseInt(portalJson.APP_PARAM_DATA.ccExpiredDateFactor, 10);
                }
            }
            if (portalJson.APP_CMS_DATA && portalJson.APP_CMS_DATA.cmsSpot) {
                this._override.cms = portalJson.APP_CMS_DATA.cmsSpot;
            }
        } else {
            this.query();
        }
    }

    /**
     * To evaluvate the mode is standlone
     * If yes get data from query param
     */
    private static query() {
        const params = Utils.getParams();
        if (params) {
            if (has(params, 'env') || has(params, 'fenv')) {
                this.env = params['env'] || params['fenv'];
            }
            Object.assign(this._override, {
                tokenID: params['tokenId'] || params['tokenID'] || params['tokenid'] || this._override.tokenID,
                serviceUID: params['apiKey'] || this._override.serviceUID,
                serviceSALT: params['apiSecret'] || this._override.serviceSALT,
                ipAddress: params['ipAddress'] || this._override.ipAddress,
                xid: params['xid'] || params['xid'] || params['XID'] || params['XID'] || this._override.xid || '',
                faststyle: params['faststyle'],
                orderNo: params['orderNo'],
                isRegistered: params['isRegistered'],
                reasonCode: (window.location.href.indexOf('localhost') > -1 || window.location.href.indexOf('10.254.247.2') > -1 ) && params['reasonCode'] ? params['reasonCode'] : '',
                alertType: params['alertType'],
                regStatus: params['regStatus'],
                timeoutURL: params['timeoutURL'],
                landingPageURL: params['landingPageURL'],
                workFlowContext: params['workFlowContext'],
                webTrendsMsgId: params['webTrendsMsgId']
            });
        }
    }

    /**
     * Mutator for env value
     */
    static set env(env) {
        this._env = (env in ENV) && ENV[env];
    }

    /**
     * Accessor for env
     */
    static get env() {
        return this._env;
    }

    /**
     * To initialise the configuration based on environment
     *
     * @param env enviroment flag
     */
    static init(env: ENV) {
        this.native();
        const prefferedEnv = this.env || env || ENV.prod;
        this.config = merge({}, this._config, globalConfig[ENV[prefferedEnv]] || globalConfig.prod, this._override);
    }
}
