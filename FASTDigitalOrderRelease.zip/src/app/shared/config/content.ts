import { ALERT_TYPE } from '../enum';

export const Contents = {
    states: [
        'AA', 'AB', 'AE', 'AK', 'AL', 'AP', 'AR', 'AS', 'AZ', 'BC', 'CA', 'CO', 'CT', 'DC', 'DE', 'EU', 'FL', 'FM', 'GA', 'GU', 'HI', 'IA', 'ID', 'IL', 'IN', 'KS', 'KY', 'LA', 'LB',
        'MA', 'MB', 'MD', 'ME', 'MI', 'MN', 'MO', 'MP', 'MS', 'MT', 'MX', 'NB', 'NC', 'ND', 'NE', 'NF', 'NH', 'NJ', 'NM', 'NS', 'NT', 'NV', 'NY', 'OH', 'OK', 'ON', 'OR', 'PA', 'PE',
        'PQ', 'PR', 'PW', 'RI', 'SC', 'SD', 'SK', 'TN', 'TX', 'UT', 'VA', 'VI', 'VT', 'WA', 'WI', 'WV', 'WY', 'YT'
    ],
    sessionTimeoutAlertMins: 13,
    sessionLastTimeoutMins: 2,
    registerBtn: {
        text: 'Register',
        alt: 'Register at Caremark.com to manage your prescriptions.'
    },
    signInBtn: {
        text: 'Sign in',
        alt: 'Sign in at Caremark.com to manage your prescriptions.'
    },
    expiration: {
        expired: 'Expired',
        soon: 'Expiring soon'
    },
    modal: {
        cancelOrder: {
            title: 'Are you sure you want to cancel this order?',
            body: '<p>If you select "Yes, cancel this order," you\'re asking us not to ship any items in this order.</p>',
            primaryButton: 'Yes, cancel this order',
            secondaryButton: 'No, go back'
        },
        sessionTimeout: {
            title: 'Your session is about to expire.',
            body: 'Your session will expire in 2 minutes. If you\'d like to stay signed in, select "Continue session."',
            primaryButton: 'Continue session',
            secondaryButton: 'Sign out'
        }
    },
    alert: {
        header: 'Something\'s not right.',
        missingInfoHeader: 'We\'re missing some information.',
        noPaymentSelected: 'Please select a payment method.',
        onePrescriptionToContinue: 'Please select a prescription to continue.',
        noConsentChosen: {
            title: 'We\'re missing some information.',
            linkText: 'Please select whether you consent to pay for this medication.'
        },
        invalidAddress: {
            address: 'Enter a valid address.',
            city: 'Enter a valid city.',
            state: 'Select a state.',
            zipCode: 'Enter a valid ZIP code.'
        },
        invalidAccount: {
            firstName: 'Enter a first name.',
            lastName: 'Enter a last name.',
            accountNumber: 'Enter a valid account number.',
            routingNumber: 'Enter a valid routing number.',
            accountType: 'Select an account type. '
        },
        invalidCard: {
            cardNumber: 'Enter a valid card number.',
            invalidExpiry: 'Select an expiration date in the future.',
            invalidMonth: 'Select an expiration month.',
            invalidYear: 'Select an expiration year.'
        },
        orderReleased: {
            title: 'You\'ve released your order',
            description: 'Your hold has been resolved and your medications are being shipped.'
        },
        orderReleasedIndefinite: {
            title: 'You\'ve placed your order',
            description: 'Your hold has been resolved and your medications are being shipped.'
        },
        onServiceError: {
            title: 'Something\'s not right',
            description: 'We\'re sorry, this service is currently unavailable.'
        },
        onOrderResolved: {
            title: 'You\'re all set.',
            description: 'Your hold on order #<#####> has already been resolved. You can check your order status by signing in or registering below.'
        },
        onOrderCancelled: {
            title: 'Order #<#####> has been canceled.'
        }
    },
    accountBalance: {
        header: 'Account balance',
        mailServiceCost: 'Mail service estimated cost:',
        shippingcost: 'Estimated shipping cost:',
        outstandingBalance: 'Outstanding mail service balance:',
        totalDue: 'Estimated total due now:'
    },
    paymentDivert: {
        header: 'Release your order',
        introText1: '',
        introText2: 'Review your order details below to fix the issues and release your order for shipment.',
        hourNotice: 'Any medications in this order that don\'t have issues will be released for shipment on',
        medicationHeader: 'Medications in this order',
        paymentHeader: 'Payment method'
    }
};
