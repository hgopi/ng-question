import { FormControl, ValidationErrors, FormGroup, AbstractControl, ValidatorFn } from '@angular/forms';

export class CustomValidators {

  static dob(c: FormControl): ValidationErrors {
      const date: string = c.value;
      let isValid = true;
      const currentDate = new Date();
      const enteredDate = new Date(date);
      const year = +date.substr(-4);
      const day = +date.substr(3, 2);
      const month = +date.substr(0, 2) - 1;
      if (!(/^(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\/(19|20)\d{2}$/.test(date))) {
        isValid = false;
      } else if (!(enteredDate instanceof Date) || enteredDate.toString() === 'Invalid Date') {
        isValid = false;
      } else if (enteredDate.getFullYear() !== year || enteredDate.getMonth() !== month || enteredDate.getDate() !== day) {
        isValid = false;
      } else if (enteredDate > currentDate) {
        isValid = false;
      } else if (enteredDate < new Date('01/01/1900')) {
        isValid = false;
      }
      return isValid ? null : { invalid: true };
  }

  static creditCard(c: FormControl): ValidationErrors {
    let cardNumber = c.value;
    cardNumber = cardNumber.replace(/\s/g, '');
    let len = cardNumber.length;
    let isValid;
    let mul = 0;
    const prodArr = [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [0, 2, 4, 6, 8, 1, 3, 5, 7, 9]];
    let sum = 0;

    while ( len-- ) {
      sum += prodArr[mul][parseInt(cardNumber.charAt(len), 10)];
      mul ^= 1;
    }

    if (sum % 10 === 0 && sum > 0) {
      isValid = true;
    } else {
      isValid = false;
    }

    return isValid ? null : { invalidCreditCard: true };
  }

  static isCardExpired(form: FormGroup) {
    const month = form.get('expiryMonth').value;
    const year = form.get('expiryYear').value;
    return (form.get('expiryMonth').valid && form.get('expiryYear').valid) &&
    (month && year && (new Date(year, month) < new Date())) ? { isCardExpired: true } : null;
  }

  static requiredIf(requiredIf: boolean): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = control.value;
      if ((value === null || value === undefined || value === '') && requiredIf) {
        return {
          requiredIf: this.requiredIf
        };
      }
      return null;
    };
  }

  static validateZipcode(c: FormControl): ValidationErrors {
    const value = c.value;
    if (value.length > 5 && value.length < 10) {
      return {
        invalidZip: true
      };
    }
    return null;
  }

}
