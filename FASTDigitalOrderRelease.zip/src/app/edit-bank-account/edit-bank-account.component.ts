import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Location } from '@angular/common';
import { BackEndService } from '../shared/services';
import { AlertData } from '../shared/components/index';
import { ALERT_TYPE } from '../shared/enum';
import { Contents } from '../shared/config/content';
import { AppState } from '../shared/state/AppState';

@Component({
  selector: 'edit-bank-account',
  templateUrl: './edit-bank-account.component.html',
  styleUrls: ['./edit-bank-account.component.scss']
})
export class EditBankAccountComponent implements OnInit {

  formSubmitted = false;
  bankAccountForm: FormGroup;
  formError = <AlertData>{
    type: ALERT_TYPE.NONE,
    data: {
      title: Contents.alert.header
    }
  };
  errorContent = Contents.alert.invalidAccount;

  constructor(private _fb: FormBuilder, private _location: Location, private _backEnd: BackEndService, private _appState: AppState) {
    this.constructForm();
  }

  ngOnInit() {
  }

  constructForm() {
    this.bankAccountForm = this._fb.group({
      firstName:     [ '', Validators.required ],
      lastName:      [ '', Validators.required ],
      routingNumber: [ '', Validators.required ],
      accountNumber: [ '', Validators.required ],
      accountType:   [ '', Validators.required ]
    });
  }

  onBackPressed() {
    this._location.back();
  }

  saveUpdates() {
    this.formSubmitted = true;
    if (this.bankAccountForm.valid) {
      this._backEnd.addAccount(this.bankAccountForm.getRawValue()).subscribe((data) => {
        this.setShippingError(data);
        this._location.back();
      }, (error) => {
        console.log(error);
        this.formError = Object.assign({}, {
          type: ALERT_TYPE.ERROR,
          data: {
            ...Contents.alert.onServiceError
          }
        });
      });
    } else {
      const label = [];
      Object.keys(this.bankAccountForm.controls).forEach((key) => {
        if (this.bankAccountForm.get(key).errors) {
          label.push({
            for: key,
            text: this.errorContent[key]
          });
        }
      });
      this.formError = Object.assign({}, {
        type: ALERT_TYPE.ERROR,
        data: {
          title: Contents.alert.header,
          label: label
        }
      });
    }
  }

  setShippingError(data) {
    if (data && data.error) {
      this._appState.setShippingError({ isError: true });
    } else {
      this._appState.setShippingError({ isError: false });
    }
  }

}
