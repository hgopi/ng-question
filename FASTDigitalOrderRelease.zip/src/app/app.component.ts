import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BackEndService } from './shared/services/index';
import { CONSENTS } from './shared/enum';
import { CMSConstants } from './shared/config/cms-constants';
import { Router, NavigationEnd } from '@angular/router';
import { Utils } from './shared/utils';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
    
  routeChange$: Subscription;  
  loadAPI: Promise<any>;
  cmsContent = CMSConstants;

  constructor(private _router: Router) {
    this.loadAPI = new Promise((resolve) => {
      this.loadScript();
      resolve(true);
    });
  }

  public loadScript() {
    let isFound = false;
    const scripts = document.getElementsByTagName('script');

    for (let i = 0; i < scripts.length; ++i) {
      if (scripts[i].getAttribute('src') != null && scripts[i].getAttribute('src').includes('fastlib')) {
        isFound = true;
      }
    }
    if (!isFound) {
      const dynamicScript = 'https://sit2fast.caremark.com/FASTConfig/fastlib.js';
      const node = document.createElement('script');
      node.src = dynamicScript;
      node.type ='text/javascript';
      node.async = false;
      node.charset = 'utf-8';
      document.getElementsByTagName('head')[0].appendChild(node);
    }
  }

  ngOnInit(): void {
    this.routeChange$ = this._router.events.subscribe((e) => {
      if (!(e instanceof NavigationEnd)) {
        return;
      }
      Utils.scrollToTop();
    });
  }

  ngOnDestroy(): void {
    this.routeChange$.unsubscribe();
  }

}


