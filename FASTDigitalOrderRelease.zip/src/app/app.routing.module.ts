import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ConfirmationComponent } from './confirmation/confirmation.component';
import { ConsentPaymentComponent } from './consents/consent-payment/consent-payment.component';
import { EditCardComponent } from './edit-card/edit-card.component';
import { EditBankAccountComponent } from './edit-bank-account/edit-bank-account.component';
import { ConsentShipComponent } from './consents/consent-ship/consent-ship.component';
import { ConsentRxPaymentComponent } from './consents/consent-rx-payment/consent-rx-payment.component';
import { ConsentsComponent } from './consents/consents.component';
import { ROUTE_PATHS } from './shared/enum';
import { ContentsResolver } from './shared/resolver/contents.resolver';
import { RouteGuard } from './shared/resolver/route-guard.service';

const routes: Routes = [
  { path: ROUTE_PATHS.INDEX,  component: ConsentsComponent, resolve: { initDate: ContentsResolver } },
  { path: ROUTE_PATHS.CONFIRMATION, component: ConfirmationComponent, canActivate: [RouteGuard] },
  { path: ROUTE_PATHS.EDIT_CARD, component: EditCardComponent, canActivate: [RouteGuard] },
  { path: ROUTE_PATHS.EDIT_BANK_ACC, component: EditBankAccountComponent, canActivate: [RouteGuard] },
  { path: '**', redirectTo: ROUTE_PATHS.INDEX }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule {

}
