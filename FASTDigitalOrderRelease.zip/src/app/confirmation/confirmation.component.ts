import { Component, OnInit, OnDestroy, AfterViewInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AlertData } from '../shared/components/alert/alert.component';
import { environment } from '../../environments/environment';
import { ALERT_TYPE, RELEASE_STATUS, ORDER_ALERT_TYPE, STATES, CONSENTS } from '../shared/enum';
import { AppState } from '../shared/state/AppState';
import { OrderDetails, PaymentList, ShippingMethod } from '../shared/state/iState';
import { Subscription } from 'rxjs/Subscription';
import { TealiumUtagService } from '../shared/services/utag.service';
import { Tagging } from '../shared/config/tagging-constants';
import { Contents } from '../shared/config/content';

@Component({
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.scss']
})
export class ConfirmationComponent implements OnInit, OnDestroy, AfterViewInit {
  shippingMethod$: Subscription;
  paymentDetails$: Subscription;
  orderDetails$: Subscription;
  shippingMethod: any;
  orderNumber: any;
  selectedPayment: any;
  accountBalance: any;
  shippingAddress: { fullName: string; addressLine: string; };
  rxList: any;
  isIndefiniteHold = false;
  private _alert: AlertData[];

  isCancelled: boolean;

  constructor(private _appState: AppState, private _analytics: TealiumUtagService) {
    this.isCancelled = this._appState.getOnHoldReleaseStatus() === RELEASE_STATUS.CANCELLED;
    this.orderDetails$ = this._appState.select<OrderDetails>('orderDetails').subscribe((details) => {      
      this.rxList = details.selectedRx;
      this.orderNumber = details.orderNumber;
      this.isIndefiniteHold = details.reasonCode === CONSENTS.INDEFINITE_HOLD;
    });
    this.paymentDetails$ = this._appState.select<PaymentList>('paymentsList').subscribe((details) => {
      this.selectedPayment = details.selectedPayment;
    });
    this.shippingMethod$ = this._appState.select<ShippingMethod>(STATES.SHIPPING_METHOD).subscribe((details) => {
      this.shippingMethod = details.selectedMethod;
    });

    // this.orderNumber = this._appState.getOrderNumber();
    this._alert = [
      {
        type: ALERT_TYPE.INFO,
        data: {
          title: Contents.alert.onOrderCancelled.title.replace('<#####>', this.orderNumber)
        }
      },
      {
        type: ALERT_TYPE.SUCCESS,
        data: {
          ...Contents.alert.orderReleased
        }
      },
      {
        type: ALERT_TYPE.SUCCESS,
        data: {
          ...Contents.alert.orderReleasedIndefinite
        }
      }
    ];
  }

  ngOnInit(): void {
  }

  ngAfterViewInit() {
    this._analytics.view({
      Page_Name: Tagging.ConfirmationPageLoad,
      Page_category: Tagging.OnHoldPageName,
      payment_method: this.selectedPayment ? (this.selectedPayment.ElectronicPaymentAccountID || this.selectedPayment.ePayAccountID) : 0,
      drug_counter: this.rxList.length
    });
  }

  ngOnDestroy(): void {
    this.orderDetails$.unsubscribe();
    this.paymentDetails$.unsubscribe();
    this.shippingMethod$.unsubscribe();
  }

  register() {
    if (window.parent) {
      window.parent.location.href = environment.timeoutURL + 'REGISTER_ONLINE';
    } else {
      window.location.href = environment.timeoutURL + 'REGISTER_ONLINE';
    }
  }

  signIn() {
    if (window.parent) {
      window.parent.location.href = environment.timeoutURL;
    } else {
      window.location.href = environment.timeoutURL;
    }
  }

  get cancelAlert() {
    return this._alert[0];
  }

  get successAlert() {
    return (this.isIndefiniteHold ? this._alert[2] : this._alert[1]);
  }

}
