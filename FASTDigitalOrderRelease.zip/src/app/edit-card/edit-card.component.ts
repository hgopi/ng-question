import { Component, OnInit, Input, Output, EventEmitter, OnDestroy, Renderer2, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AlertData } from '../shared/components/index';
import { Location } from '@angular/common';
import { AppState } from '../shared/state/AppState';
import { Subscription } from 'rxjs/Subscription';
import { Utils } from '../shared/utils';
import { BackEndService } from '../shared/services/index';
import { CustomValidators } from '../shared/validators/custom.validators';
import { ALERT_TYPE, STATES } from '../shared/enum';
import { PaymentList } from '../shared/state/iState';
import { Contents } from '../shared/config/content';

@Component({
  selector: 'edit-card',
  templateUrl: './edit-card.component.html',
  styleUrls: ['./edit-card.component.scss']
})
export class EditCardComponent implements OnInit, OnDestroy {

  cardDetails$: Subscription;

  editCardForm: FormGroup;
  cardNumber: String = '';
  expiresOn: { month: string, year: string } = {
    month: '',
    year: ''
  };
  years = [];
  isReadOnly = false;
  mode = 'add';
  cardDetails: any;
  formSubmitAttempt: boolean;
  alert = <AlertData>{
    type: ALERT_TYPE.NONE,
    data: {
      title: 'Something\'s not right.'
    }
  };

  constructor(
    private fb: FormBuilder,
    private _location: Location,
    private _appState: AppState,
    private _backEnd: BackEndService,
    private _renderer: Renderer2) {
      this.cardDetails$ = this._appState.select<PaymentList>(STATES.PAYMENTS_LIST).subscribe((payments) => {
        if (payments.editPayment && payments.editPayment.details) {
          this.cardDetails = payments.editPayment.details;
          this.cardNumber = this.cardDetails.AccountName.split('-')[1];
          if (!(this.cardDetails.expire && this.cardDetails.expire.text === 'Expired')) {
            this.expiresOn = {
              month: this.cardDetails.ExpirationDate.split('/')[0],
              year: this.cardDetails.ExpirationDate.split('/')[1]
            };
          }
          this.isReadOnly = true;
          this.mode = 'edit';
        }
        this.getYearsRange();
        this.constructForm();
      });
  }

  ngOnInit() {

  }

  constructForm() {
    this.editCardForm = this.fb.group({
      expiryMonth: [ this.expiresOn.month, Validators.required ],
      expiryYear: [ this.expiresOn.year, Validators.required ]
    }, {
      validator: CustomValidators.isCardExpired
    });
    if (this.isAddMode) {
      const validators = [ Validators.required, CustomValidators.creditCard ];
      this.editCardForm.addControl('cardNumber', this.fb.control('', validators));
    }
    this.formSubmitAttempt = false;
  }

  onBackPressed() {
    this._location.back();
  }

  saveUpdates() {
    this.formSubmitAttempt = true;
    if (this.editCardForm.valid) {
      const formValues = this.editCardForm.getRawValue();
      if (this.isAddMode) {
        this._backEnd.addCreditCard(formValues).subscribe((data) => {
          this.setShippingError(data);
          this._location.back();
        }, (error) => {
          console.log(error);
          this.showServiceError();
        });
      } else {
        formValues.cardNumber = this.cardDetails.AccountName;
        formValues.ElectronicPaymentAccountID = this.cardDetails.ElectronicPaymentAccountID;
        this._backEnd.updateCard(formValues).subscribe((data) => {
          this.setShippingError(data);
          this._location.back();
        }, (error) => {
          console.log(error);
          this.showServiceError();
        });
      }
    } else {
      const label = [];
      if (this.isAddMode && this.editCardForm.get('cardNumber').errors) {
        label.push({
          for: 'cardNumber',
          text: Contents.alert.invalidCard.cardNumber,
        });
      }
      if (this.editCardForm.get('expiryMonth').errors) {
        label.push({
          for: 'expiryMonth',
          text: Contents.alert.invalidCard.invalidMonth
        });
      }
      if (this.editCardForm.get('expiryYear').errors) {
        label.push({
          for: 'expiryYear',
          text: Contents.alert.invalidCard.invalidYear
        });
      }
      if (this.editCardForm.errors && this.editCardForm.errors.isCardExpired) {
        label.push({
          for: 'expiryMonth',
          text: Contents.alert.invalidCard.invalidExpiry
        });
      }
      this.alert = Object.assign({}, {
        type: ALERT_TYPE.ERROR,
        data: {
          title: Contents.alert.header,
          label: label
        }
      });
    }
  }

  setShippingError(data) {
    if (data && data.error) {
      this._appState.setShippingError({ isError: true });
    } else {
      this._appState.setShippingError({ isError: false });
    }
  }

  showServiceError() {
    this.alert = {
      type: ALERT_TYPE.ERROR,
      data: {
        ...Contents.alert.onServiceError
      }
    };
  }

  get isAddMode() {
    return this.mode === 'add';
  }

  getYearsRange() {
    let currentYear = parseInt(this.expiresOn.year, 10) || new Date().getFullYear();
    const endYear = currentYear + 20;
    for (; currentYear <= endYear; currentYear++) {
      this.years.push(currentYear);
    }
  }

  ngOnDestroy() {
    this.cardDetails$.unsubscribe();
  }

}
