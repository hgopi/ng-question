import { Component, OnDestroy } from '@angular/core';
import { BackEndService } from './../shared/services';
import { CONSENTS, ALERT_TYPE, STATES } from './../shared/enum';
import { environment } from '../../environments/environment';
import { AppState } from '../shared/state/AppState';
import { AlertData } from '../shared/components/index';
import { OrderDetails } from '../shared/state/iState';
import { Subscription } from 'rxjs/Subscription';
import { TealiumUtagService } from '../shared/services/utag.service';
import { Tagging } from '../shared/config/tagging-constants';
import { Contents } from '../shared/config/content';

export enum REG_STATUS {
  SIGN_IN = '01',
  REGISTER = '02'
}

export enum ORDER_STATUS_TEXT {
  'consent to pay' = 1,
  'payment issue',
  'ship consent',
  'indefinite hold'
}

@Component({
  template: `
      <app-alert [config]="orderResolved"></app-alert>      
      <button class="btn primary-btn col-12 col-md-3" *ngIf="isNoReasonCode" [attr.title]="btnAlt" (click)="onButtonClick()">{{ btnTxt }}</button>
      <consent-payment *ngIf="isConsentPayment"></consent-payment>
      <consent-rx-payment *ngIf="isConsentRxPayment"></consent-rx-payment>
      <consent-ship *ngIf="isConsentShip"></consent-ship>
      <consent-indefinite-hold *ngIf="isConsentIndefinite"></consent-indefinite-hold>
    `
})
export class ConsentsComponent implements OnDestroy {
  
  btnTxt: string;
  btnAlt: string;
  isNoReasonCode = false;
  orderNumber: string;
  orderDetails$: Subscription;
  address: any;
  private reasonCode: number;
  orderResolved = <AlertData>{
    type: ALERT_TYPE.NONE,
    data: {
      ...Contents.alert.onOrderResolved
    }
  };

  constructor(private _backEnd: BackEndService, private _appState: AppState, private _analytics: TealiumUtagService) {
    this.orderDetails$ = this._appState.select<OrderDetails>(STATES.ORDER_DETAILS).subscribe((details) => {
      const orderDetails = details;
      this.reasonCode = orderDetails.reasonCode;
      this.orderNumber = orderDetails.orderNumber;
      if (this.reasonCode > 0) {
        this._analytics.view({
          Page_Name: Tagging.OnHoldPageName,
          Page_Category: Tagging.OnHoldPageCategory,
          rx_count: orderDetails.displayRx.length,
          order_status: ORDER_STATUS_TEXT[this.reasonCode]
        });
      } else {
        this._analytics.view({
          Error_Messages: 'N/A',
        });
      }
    });

    if (this.reasonCode === 0) {
      const content = Contents.alert.onOrderResolved;
      this.orderResolved = {
        type: ALERT_TYPE.INFO,
        data: {
          title: content.title,
          description: content.description.replace('<#####>', this.orderNumber)
        }
      };
      this.isNoReasonCode = true;
      this.btnTxt = environment.regStatus === REG_STATUS.REGISTER ? Contents.registerBtn.text : Contents.signInBtn.text;
      this.btnAlt = environment.regStatus === REG_STATUS.REGISTER ? Contents.registerBtn.alt : Contents.signInBtn.alt;
    } else if (!this.reasonCode || !this.orderNumber) {
      this.orderResolved = {
        type: ALERT_TYPE.ERROR,
        data: {
          ...Contents.alert.onServiceError
        }
      };
    }
  }

  onButtonClick() {
    let url = environment.timeoutURL;
    if (environment.regStatus === REG_STATUS.REGISTER) {
      url += 'REGISTER_ONLINE';
    }
    if (window.parent) {
      window.parent.location.href = url;
    } else {
      window.location.href = url;
    }
  }

  get isConsentPayment() {
    return this.reasonCode && this.reasonCode === CONSENTS.PAYMENT_ONLY;
  }

  get isConsentRxPayment() {
    return this.reasonCode && this.reasonCode === CONSENTS.RX_AND_PAYMENT;
  }

  get isConsentShip() {
    return this.reasonCode && this.reasonCode === CONSENTS.MED_D_SHIPMENT;
  }

  get isConsentIndefinite() {
    return this.reasonCode && this.reasonCode === CONSENTS.INDEFINITE_HOLD;
  }

  ngOnDestroy() {
    this.orderDetails$.unsubscribe();
  }

}
