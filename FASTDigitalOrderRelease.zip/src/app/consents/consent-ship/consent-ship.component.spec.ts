import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsentShipComponent } from './consent-ship.component';

describe('ConsentShipComponent', () => {
  let component: ConsentShipComponent;
  let fixture: ComponentFixture<ConsentShipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsentShipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsentShipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
