import { Component, OnInit, Renderer2, OnDestroy } from '@angular/core';
import { ModalService } from './../../shared/components/modal/modal.service';
import { Router } from '@angular/router';
import { ROUTE_PATHS, RELEASE_STATUS, STATES, ALERT_TYPE, CARD_TYPE } from './../../shared/enum';
import { AppState } from '../../shared/state/AppState';
import { BackEndService } from '../../shared/services/back-end.service';
import { Contents } from '../../shared/config/content';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AlertData, MODAL_TYPE } from '../../shared/components/index';
import { findIndex } from 'lodash-es';
import { OrderDetails, PaymentList } from '../../shared/state/iState';
import { CMSConstants } from '../../shared/config/cms-constants';
import { Subscription } from 'rxjs/Subscription';
import { CapitalizePipe } from '../../shared/pipes/capitalize.pipe';
import { TealiumUtagService } from '../../shared/services/utag.service';
import { Tagging } from '../../shared/config/tagging-constants';

@Component({
  selector: 'consent-ship',
  templateUrl: './consent-ship.component.html',
  styleUrls: ['./consent-ship.component.scss']
})
export class ConsentShipComponent implements OnInit, OnDestroy {
  
  paidAccount: any;
  orderDetails$: Subscription;
  cardType: string;
  selectedPayment: any;
  orderDetails: any;
  selectRxForm = this._fb.group({
  });
  formSubmitted = false;
  cmsContent = CMSConstants;
  alert = <AlertData>{
    type: ALERT_TYPE.NONE,
    data: {
      title: Contents.alert.noConsentChosen.title,
      link: {
        text: Contents.alert.noConsentChosen.linkText,
        callback: () => {
          const input = this._renderer.selectRootElement('input.ng-invalid');
          input && input.focus();
        }
      }
    }
  };

  constructor(private _router: Router,
    private _modalService: ModalService,
    private _appState: AppState,
    private _backEnd: BackEndService,
    private _fb: FormBuilder,
    private _renderer: Renderer2,
    private _capitalize: CapitalizePipe,
    private _analytics: TealiumUtagService) {

      this.orderDetails$ = this._appState.select<OrderDetails>(STATES.ORDER_DETAILS).subscribe((details) => {
        this.orderDetails = details;
        this.selectedPayment = this.orderDetails.paymentAccount;
        this.cardType = this._capitalize.transform(CARD_TYPE[this.selectedPayment.paymentTypeCode]);
        const payments = this._appState.subject.paymentsList.value;
        this.paidAccount = this.getSelectedPayment(payments);
      });
      this.initForm();
    }

  getSelectedPayment(payments) {
    let selectedPaymentIndex = null;
    if (this.selectedPayment && payments) {
      selectedPaymentIndex = findIndex(payments.card, (payment) => {
        return payment.ElectronicPaymentAccountID === this.selectedPayment.ePayAccountID;
      });
      if (selectedPaymentIndex < 0) {
        selectedPaymentIndex = findIndex(payments.bank, (payment) => {
          return payment.ElectronicPaymentAccountID === this.selectedPayment.ePayAccountID;
        });
        this._appState.setSelectedPayment('bank', selectedPaymentIndex);
        return payments['bank'][selectedPaymentIndex];
      } else {
        this._appState.setSelectedPayment('card', selectedPaymentIndex);
        return payments['card'][selectedPaymentIndex];
      }
    }
  }

  ngOnInit() {
  }

  initForm() {
    this.orderDetails.displayRx.forEach((rx, i) => {
      this.selectRxForm.addControl(`shipMedication_${i}`, this._fb.control('', [Validators.required]));
    });
  }

  checkboxChecked(i) {
    const selected = this.orderDetails.displayRx[i];
    this.orderDetails.displayRx[i].isSelected = true;
    this._appState.updateCost(selected.payAmount);
  }

  checkboxUnchecked(i) {
    const selected = this.orderDetails.displayRx[i];
    if (selected.isSelected) {
      this._appState.updateCost( -selected.payAmount );
    }
    this.orderDetails.displayRx[i].isSelected = false;
  }

  releaseOrder() {
    this.formSubmitted = true;
    if (this.selectRxForm.valid) {
      this._analytics.link({
        onhold_submit: Tagging.OnHoldSubmit,
        link_name: Tagging.OnHoldSubmitLink
      });
      this._appState.setOnHoldReleaseStatus(RELEASE_STATUS.RELEASED);
      this._appState.setSelectedRx(this.orderDetails.displayRx);
      this._backEnd.multiplePlaceOrder(this.orderDetails.displayRx, true).subscribe(() => {
        this._router.navigate([ROUTE_PATHS.CONFIRMATION], {queryParamsHandling: 'merge'});
      }, (error) => {
        this.showServiceError();
      });
    } else {
      this.alert = Object.assign({}, this.alert, { type: ALERT_TYPE.ERROR });      
    }
  }

  cancelOrder() {
    this._modalService.open({
      type: MODAL_TYPE.ORDER_CANCEL,
      data: {
        ...Contents.modal.cancelOrder
      },
      success: (data) => {
        this._appState.setOnHoldReleaseStatus(RELEASE_STATUS.CANCELLED);
        this._backEnd.resolveOnHoldOrderIssues(this._appState.getResolveOnHoldPayload(this.orderDetails.displayRx, RELEASE_STATUS.CANCELLED)).subscribe(() => {
          this._router.navigate([ROUTE_PATHS.CONFIRMATION], {queryParamsHandling: 'merge'});
        }, (error) => {
          this.showServiceError();
        });
      },
      cancel: (data) => {
      },
      returnFocusTo: '.secondary-btn'
    });
  }

  showServiceError() {
    this.alert = Object.assign({}, {
      type: ALERT_TYPE.ERROR,
      data: {
        ...Contents.alert.onServiceError
      }
    });
  }

  ngOnDestroy(): void {
    this.orderDetails$.unsubscribe();
  }

}
