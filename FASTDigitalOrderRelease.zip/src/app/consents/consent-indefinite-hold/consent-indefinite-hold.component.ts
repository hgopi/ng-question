import { Component, OnInit, OnDestroy } from '@angular/core';
import { ModalService, AlertData, MODAL_TYPE } from '../../shared/components/index';
import { Router } from '@angular/router';
import { ROUTE_PATHS, RELEASE_STATUS, STATES, ALERT_TYPE } from '../../shared/enum';
import { Contents } from '../../shared/config/content';
import { AppState } from '../../shared/state/AppState';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { CustomValidators } from '../../shared/validators/custom.validators';
import { BackEndService } from '../../shared/services/index';
import { map, filter } from 'rxjs/operators';
import { findIndex, groupBy } from 'lodash-es';
import { OrderDetails, ShippingMethod, AddressDetails } from '../../shared/state/iState';
import { CMSConstants } from '../../shared/config/cms-constants';
import { Subscription } from 'rxjs/Subscription';
import { TealiumUtagService } from '../../shared/services/utag.service';
import { Tagging } from '../../shared/config/tagging-constants';
import { Utils } from '../../shared/utils';
import { CapitalizePipe } from '../../shared/pipes/capitalize.pipe';

@Component({
  selector: 'consent-indefinite-hold',
  templateUrl: './consent-indefinite-hold.component.html',
  styleUrls: ['./consent-indefinite-hold.component.scss']
})
export class ConsentIndefiniteHoldComponent implements OnInit, OnDestroy {
  memberRxsKeys: string[];
  memberRxs: any;
  componentState$: Subscription;
  addressList$: Subscription;
  shippingMethod$: Subscription;
  orderDetails$: Subscription;

  selectedRx = [];
  states: string[];
  savedState: any;
  shippingMethods: any;
  addressList: any;
  orderDetails: any;
  rxList: any;
  paymentList: any;
  accountBalance: any;
  private currentStep = 1;
  selectRxForm = this._fb.group({
  });
  submitOrderForm: FormGroup;
  totalSelectedRxCost = 0;
  formSubmitAttempt = false;
  formDoContinueAttempt = false;
  alert = <AlertData>{
    type: ALERT_TYPE.NONE,
    data: {
      title: Contents.alert.header
    }
  };
  paymentAlert = <AlertData>{
    type: ALERT_TYPE.NONE,
    data: {
      title: Contents.alert.missingInfoHeader,
      link: {
        text: Contents.alert.noPaymentSelected,
        callback: () => {
          const focusable = document.querySelector('.payment-list a, .payment-list input') as HTMLElement;
          focusable && focusable.focus();
        }
      }
    }
  };
  cmsContent = CMSConstants;

  constructor(private _appState: AppState,
    private _modalService: ModalService,
    private _router: Router,
    private _fb: FormBuilder,
    private _backEnd: BackEndService,
    private _capitalize: CapitalizePipe,
    private _analytics: TealiumUtagService) {
      this.orderDetails$ = this._appState.select<OrderDetails>(STATES.ORDER_DETAILS).subscribe((details) => {
        this.orderDetails = details;
        this.memberRxs = groupBy(this.orderDetails.displayRx, (rx) => rx.patientFirstName);
        this.memberRxsKeys = Object.keys(this.memberRxs);
        this.initSelectRxForm();
      });
      this.shippingMethod$ = this._appState.select<ShippingMethod>(STATES.SHIPPING_METHOD).subscribe((details) => {
        this.shippingMethods = details.shippingMethods;
        this.initSubmitOrderForm();
      });
      this.addressList$ = this._appState.select<AddressDetails>(STATES.ADDRESS_LIST).subscribe((details) => {
        this.addressList = details.addressList;
      });
      this.componentState$ = this._appState.select(STATES.COMPONENT_STATE).pipe(filter((state: any) => state !== null)).subscribe((state) => {
        if (state.selectRxForm) {
          this.selectRxForm.patchValue(state.selectRxForm);
          Object.keys(state.selectRxForm).forEach((key) => {
            // this.rxItemChanged(key, parseInt(key.split('_')[1], 10));
          });
        }
        if (state.submitOrderForm) {
          this.submitOrderForm.patchValue(state.submitOrderForm);
        }
        if (state.currentStep) {
          this.currentStep = state.currentStep;
        }
      });
      this.states = Contents.states;
  }

  ngOnInit() {
  }

  initSelectRxForm() {
    this.memberRxsKeys.forEach((key, index) => {
      this.memberRxs[key].forEach((rx, i) => {
        this.selectRxForm.addControl(`rx_${index}_${i}`, this._fb.control(''));
      });
    });    
  }

  initSubmitOrderForm() {
    this.submitOrderForm = this._fb.group({
      addressOption: ['existing'],
      selectedExisting: [0],
      methodOption: [this.shippingMethods && this.shippingMethods.length ? this.shippingMethods[0].ShippingCode : '']
    });
    this.submitOrderForm.get('addressOption').valueChanges.subscribe((option) => {
      if (option === 'new') {
        this.submitOrderForm.addControl('newAddress', this.getAddressFormGroup());
        this.formSubmitAttempt = false;
      } else {
        this.submitOrderForm.removeControl('newAddress');
      }
    });
  }

  formatZipcode() {
    let zipcode = this.submitOrderForm.get('newAddress').get('zipCode').value;
    if (zipcode.length > 5 && zipcode.indexOf('-') === -1) {
      zipcode = zipcode.slice(0, 5) + '-' + zipcode.slice(5);
      zipcode = this.submitOrderForm.get('newAddress').get('zipCode').setValue(zipcode);
    }
  }

  rxItemChanged(control, index, i) {
    const value = this.selectRxForm.get(control).value;
    const selected = this.memberRxs[this.memberRxsKeys[index]][i];
    const findI = findIndex(this.selectedRx, (rx) => rx.rxNumber === selected.rxNumber);
    if (value) {
      this.selectedRx.push(selected);
      this.totalSelectedRxCost += selected.payAmount;
    } else if (findI > -1) {
      this.selectedRx.splice(findI, 1);
      this.totalSelectedRxCost -= selected.payAmount;
    }
  }

  shipMethodChanged(i) {
    this._appState.updateShippingCost(parseFloat(this.shippingMethods[i].ShippingCost));
  }

  getAddressFormGroup() {
    return this._fb.group({
      address: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      zipCode: ['', [ Validators.required, CustomValidators.validateZipcode ]]
    });
  }

  get isNewAddressSelected() {
    return this.submitOrderForm.get('addressOption').value === 'new';
  }

  editRx() {
    this.currentStep = 1;
    this.alert = Object.assign({}, this.alert, {type: ALERT_TYPE.NONE});
    this.paymentAlert = Object.assign({}, this.paymentAlert, {type: ALERT_TYPE.NONE});
    this.formSubmitAttempt = false;
    Utils.scrollToTop();
  }

  doContinue() {
    this.formDoContinueAttempt = true;
    if (this.selectedRx.length > 0) {      
      this.alert = Object.assign({}, this.alert, { type: ALERT_TYPE.NONE });
      if (!this.shippingMethods) {
        this.alert = Object.assign({}, { type: ALERT_TYPE.ERROR}, { data: Contents.alert.onServiceError });
      }
      this._analytics.view({
        Page_Name: Tagging.ReviewOrderPage,
        Page_Category: Tagging.ReviewOrderPageCategory
      });
      this.currentStep++;
    } else {
      this.alert = Object.assign({}, {
        type: ALERT_TYPE.ERROR,
        data: {
          title: Contents.alert.missingInfoHeader,
          link: {
            text: Contents.alert.onePrescriptionToContinue,
            callback: () => {
              const focusable = document.querySelector('.custom-checkbox') as HTMLElement;
              focusable.focus();
            }
          }
        }
      });
    }
    setTimeout(() => this._appState.updateCost(this.totalSelectedRxCost), 0);
  }

  cancelOrder() {
    this._appState.setOnHoldReleaseStatus(RELEASE_STATUS.CANCELLED);
    this._modalService.open({
      type: MODAL_TYPE.ORDER_CANCEL,
      data: {
        ...Contents.modal.cancelOrder
      },
      success: (data) => {
        this._backEnd.resolveOnHoldOrderIssues(this._appState.getResolveOnHoldPayload(this.selectedRx, RELEASE_STATUS.CANCELLED)).subscribe((data) => {
          this._router.navigate([ROUTE_PATHS.CONFIRMATION], {queryParamsHandling: 'merge'});
        });
      },
      cancel: (data) => {
      },
      returnFocusTo: '.secondary-btn'
    });
  }

  releaseOrder() {
    this.formSubmitAttempt = true;
    this.alert.type = ALERT_TYPE.NONE;
    if (this.submitOrderForm.valid) {
      this._analytics.link({
        onhold_submit: Tagging.OnHoldSubmit,
        link_name: Tagging.OnHoldSubmitLink
      });
      this._appState.setOnHoldReleaseStatus(RELEASE_STATUS.RELEASED);
      this._appState.setSelectedShippingMethod(this.submitOrderForm.get('methodOption').value);
      this._appState.setSelectedRx(this.selectedRx);
      if (!this._appState.getSelectedPayment()) {
        this.paymentAlert = Object.assign({}, this.paymentAlert, { type: ALERT_TYPE.ERROR});
        return;
      }
      if (this.submitOrderForm.get('addressOption').value === 'new') {
        const newAddress = this.submitOrderForm.get('newAddress').value;
        const payload = {
          address: newAddress,
          selectedRx: this.selectedRx,
          releaseStatus: RELEASE_STATUS.RELEASED
        };
        this._appState.updateSelectedAddress(newAddress);
        this._backEnd.validateAddress(payload).subscribe((data) => {
          this._router.navigate([ROUTE_PATHS.CONFIRMATION], {queryParamsHandling: 'merge'});
        }, (error) => {
          this.showServiceError();
          console.log(error);
        });
      } else {
        const selectedAddress = this.addressList[this.submitOrderForm.get('selectedExisting').value];
        this._appState.updateSelectedAddress(selectedAddress);
        this._backEnd.multiplePlaceOrder(this.selectedRx, false).subscribe((data) => {
          this._router.navigate([ROUTE_PATHS.CONFIRMATION], {queryParamsHandling: 'merge'});
        }, (error) => {
          this.showServiceError();
        });

      }

    } else {
      const labels = [];
      Object.keys(this.formGroup.controls).forEach((key) => {
        if (this.formGroup.get(key).errors) {
          labels.push({
            for: key,
            text: Contents.alert.invalidAddress[key]
          });
        }
      });
      this.alert = Object.assign({}, {
        type: ALERT_TYPE.ERROR,
        data: {
          title: Contents.alert.header,
          description: '',
          label: labels
        }
      });
    }
  }

  get formGroup() {
    return <FormArray>this.submitOrderForm.get('newAddress');
  }

  hasError(controlName) {
    return this.submitOrderForm.get('newAddress').get(controlName).errors;
  }

  get isStep1Active() {
    return this.currentStep === 1;
  }

  get isStep2Active() {
    return this.currentStep === 2;
  }

  onEditPayment($event) {
    this._appState.saveComponentState({
      submitOrderForm: this.submitOrderForm.getRawValue(),
      selectRxForm: this.selectRxForm.getRawValue(),
      currentStep: this.currentStep,
      estimatedCost: this.totalSelectedRxCost
    });
  }

  showServiceError() {
    this.formSubmitAttempt = false;
    this.paymentAlert.type = ALERT_TYPE.NONE;
    this.alert = Object.assign({}, {
      type: ALERT_TYPE.ERROR,
      data: {
        ...Contents.alert.onServiceError
      }
    });
  }

  ngOnDestroy(): void {
    this.orderDetails$.unsubscribe();
    this.addressList$.unsubscribe();
    this.shippingMethod$.unsubscribe();
    this.componentState$.unsubscribe();
  }

}
