import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsentIndefiniteHoldComponent } from './consent-indefinite-hold.component';

describe('ConsentIndefiniteHoldComponent', () => {
  let component: ConsentIndefiniteHoldComponent;
  let fixture: ComponentFixture<ConsentIndefiniteHoldComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsentIndefiniteHoldComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsentIndefiniteHoldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
