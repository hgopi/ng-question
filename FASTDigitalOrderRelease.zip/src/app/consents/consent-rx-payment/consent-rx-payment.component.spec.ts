import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsentRxPaymentComponent } from './consent-rx-payment.component';

describe('ConsentRxPaymentComponent', () => {
  let component: ConsentRxPaymentComponent;
  let fixture: ComponentFixture<ConsentRxPaymentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsentRxPaymentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsentRxPaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
