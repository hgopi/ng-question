import { Component, OnInit, OnDestroy, Renderer2 } from '@angular/core';
import { Router } from '@angular/router';
import { ROUTE_PATHS, RELEASE_STATUS, ALERT_TYPE, STATES } from './../../shared/enum';
import { ModalService, AlertData } from './../../shared/components/index';
import { AppState } from '../../shared/state/AppState';
import { BackEndService } from '../../shared/services/back-end.service';
import { Contents } from '../../shared/config/content';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import findIndex from 'lodash-es/findIndex';
import { OrderDetails, ShippingError } from '../../shared/state/iState';
import { Subscription } from 'rxjs/Subscription';
import { Observable } from 'rxjs/Observable';
import { filter } from 'rxjs/operators';
import { MODAL_TYPE } from '../../shared/components/modal/modal.service';
import { TealiumUtagService } from '../../shared/services/utag.service';
import { Tagging } from '../../shared/config/tagging-constants';
import { Utils } from '../../shared/utils';

@Component({
  selector: 'consent-rx-payment',
  templateUrl: './consent-rx-payment.component.html',
  styleUrls: ['./consent-rx-payment.component.scss']
})
export class ConsentRxPaymentComponent implements OnInit, OnDestroy {
  shippngDetails$: Subscription;
  componentState$: Subscription;
  orderDetails$: Subscription;
  savedState: any;
  accountBalance: any;
  shippingAddress: { fullName: string; addressLine: string; };
  rxList: any;
  paymentList: any;
  orderDetails: any;
  address: { fullName: string; addressLine: string; };
  formSubmitted = false;

  currentStep = 1;
  selectRxForm = this._fb.group({
  });
  selectedRx = [];
  alert = <AlertData>{
    type: ALERT_TYPE.NONE,
    data: {
      title: Contents.alert.noConsentChosen.title,
      link: {
        text: Contents.alert.noConsentChosen.linkText,
        callback: () => {
          const input = this._renderer.selectRootElement('input.ng-invalid');
          input && input.focus();
        }
      }
    }
  };

  constructor(private _router: Router,
    private _modalService: ModalService,
    private _appState: AppState,
    private _backEnd: BackEndService,
    private _fb: FormBuilder,
    private _renderer: Renderer2,
    private _analytics: TealiumUtagService) {
      this.orderDetails$ = this._appState.select<OrderDetails>(STATES.ORDER_DETAILS).subscribe((details) => {
        this.orderDetails = details;
      });
      this.componentState$ = this._appState.select<any>(STATES.COMPONENT_STATE).pipe(filter(state => state !== null)).subscribe((state) => {
        if (state.currentStep) {
          this.currentStep = state.currentStep;
        }
        if (state.selectRxForm) {
          this.selectRxForm.patchValue(state.selectRxForm);
        }
        if (state.selectedRx)  {
          this.selectedRx = state.selectedRx;
        }
      });
      this.shippngDetails$ = this._appState.select<ShippingError>(STATES.SHIPPING_ERROR).subscribe((error) => {
        if (error.isError) {
          this.showServiceError();
        }
      });
      this.initSelectRxForm();
  }

  ngOnInit() {
  }

  initSelectRxForm() {
    if (this.orderDetails.displayRx) {
      this.orderDetails.displayRx.forEach((rx, i) => {
        this.selectRxForm.addControl('shipMedication_' + i, this._fb.control('', [Validators.required]));
      });

    }
    if (this.orderDetails.otherRx.length > 0 && !this.savedState) {
      const estimatedCost = this.orderDetails.otherRx.reduce((total, rx) => rx.payAmount + total, 0);
      setTimeout(() => this._appState.updateCost( estimatedCost ), 0);
    }
  }

  checkboxChecked(i) {
    const selected = this.orderDetails.displayRx[i];
    this.orderDetails.displayRx[i].isSelected = true;
    this._appState.updateCost( selected.payAmount );
  }

  checkboxUnchecked(i) {
    const selected = this.orderDetails.displayRx[i];
    if (selected.isSelected) {
      this._appState.updateCost( -selected.payAmount );
    }
    this.orderDetails.displayRx[i].isSelected = false;
  }

  doContinue() {
    this.formSubmitted = true;
    this.alert.type = ALERT_TYPE.NONE;
    if (this.selectRxForm.valid) {
      const anySelected = this.orderDetails.displayRx.some((rx) => rx.isSelected);
      if (!anySelected) {
        this.cancelOrder();
        return;
      } else {
        this._analytics.link({
          onhold_submit: Tagging.OnHoldSubmit,
          link_name: Tagging.OnHoldSubmitLink
        });
        this.currentStep++;
        Utils.scrollToTop();
      }
    } else {
      this.alert = Object.assign({}, this.alert, {type: ALERT_TYPE.ERROR});
    }
  }

  onEditPayment($event) {
    this._appState.saveComponentState({
      currentStep: this.currentStep,
      selectedRx: this.selectedRx,
      selectRxForm: this.selectRxForm.getRawValue(),
      estimatedCost: this.selectedRx.reduce((total, rx) => rx.payAmount + total, 0)
    });
  }

  get medicationsList() {
    return [...this.orderDetails.displayRx, ...this.orderDetails.otherRx];
  }

  editCallback($event) {
    this.currentStep = 1;
  }

  releaseOrder() {
    this._analytics.link({
      onhold_submit: Tagging.OnHoldSubmit,
      link_name: Tagging.OnHoldSubmitLink
    });
    this._appState.setSelectedRx(this.medicationsList);
    this._appState.setOnHoldReleaseStatus(RELEASE_STATUS.RELEASED);
    !this._appState.getSelectedPayment() && this._appState.setSelectedPaymentFromOnHoldResponse();
    this._backEnd.resolveOnHoldOrderIssues(this._appState.getResolveOnHoldPayload(this.medicationsList, RELEASE_STATUS.RELEASED)).subscribe(() => {
      this._router.navigate([ROUTE_PATHS.CONFIRMATION], {queryParamsHandling: 'merge'});
    }, (error) => {
      this.showServiceError();
    });
  }

  cancelOrder() {
    this._modalService.open({
      type: MODAL_TYPE.ORDER_CANCEL,
      data: {
        ...Contents.modal.cancelOrder
      },
      success: (data) => {
        this._appState.setOnHoldReleaseStatus(RELEASE_STATUS.CANCELLED);
        this._backEnd.resolveOnHoldOrderIssues(this._appState.getResolveOnHoldPayload(this.medicationsList, RELEASE_STATUS.CANCELLED)).subscribe(() => {
          this._router.navigate([ROUTE_PATHS.CONFIRMATION], {queryParamsHandling: 'merge'});
        }, (error) => {
          this.showServiceError();
        });
      },
      cancel: (data) => {
        console.log('secondary');
      },
      returnFocusTo: '.secondary-btn'
    });
  }

  get isStep1Active() {
    return this.currentStep === 1;
  }

  get isStep2Active() {
    return this.currentStep === 2;
  }

  isRxPenalty(penalty) {
    return penalty && penalty !== '0.0' && penalty !== '0.00';
  }

  showServiceError() {
    this.alert = Object.assign({}, this.alert, {type: ALERT_TYPE.ERROR, data: { ...Contents.alert.onServiceError }});
  }

  ngOnDestroy() {
    this.orderDetails$.unsubscribe();
    this.componentState$.unsubscribe();
    this.shippngDetails$.unsubscribe();
  }

}
