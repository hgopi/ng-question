import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsentPaymentComponent } from './consent-payment.component';

describe('ConsentPaymentComponent', () => {
  let component: ConsentPaymentComponent;
  let fixture: ComponentFixture<ConsentPaymentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsentPaymentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsentPaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
