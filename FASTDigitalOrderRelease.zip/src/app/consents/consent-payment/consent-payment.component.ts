import { Component, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';

import { ModalService } from './../../shared/components/modal/modal.service';
import { AlertData } from './../../shared/components/alert/alert.component';
import { ALERT_TYPE, ROUTE_PATHS, RELEASE_STATUS, STATES } from './../../shared/enum';
import { AppState } from '../../shared/state/AppState';
import { BackEndService, TealiumUtagService } from '../../shared/services';
import { Contents } from '../../shared/config/content';
import { MODAL_TYPE } from '../../shared/components/index';
import { OrderDetails, ShippingError } from '../../shared/state/iState';
import { Subscription } from 'rxjs/Subscription';
import { Tagging } from '../../shared/config/tagging-constants';

@Component({
  selector: 'consent-payment',
  templateUrl: './consent-payment.component.html',
  styleUrls: ['./consent-payment.component.scss']
})
export class ConsentPaymentComponent implements OnDestroy {
  
  alert = <AlertData>{
    type: ALERT_TYPE.NONE,
    data: {
      title: Contents.alert.missingInfoHeader
    }
  };

  orderDetails$: Subscription;
  shippngDetails$: Subscription;
  orderDetails: any;

  constructor(private _router: Router,
    private _modalService: ModalService,
    private _appState: AppState,
    private _backEnd: BackEndService,
    private _analytics: TealiumUtagService) {
    this.orderDetails$ = this._appState.select<OrderDetails>(STATES.ORDER_DETAILS).subscribe((details) => {
      this.orderDetails = details;
      const estimatedCost = this.orderDetails.otherRx.reduce((total, rx) => rx.payAmount + total, 0);
      this._appState.updateCost( estimatedCost );
    });
    this.shippngDetails$ = this._appState.select<ShippingError>(STATES.SHIPPING_ERROR).subscribe((error) => {
      if (error.isError) {
        this.showServiceError();
      }
    });
  }

  releaseOrder() {
    const selectedPayment = this._appState.getSelectedPayment();
    if (selectedPayment && Object.keys(selectedPayment).length > 0) {
      this._analytics.link({
        onhold_submit: Tagging.OnHoldSubmit,
        link_name: Tagging.OnHoldSubmitLink
      });
      this._appState.setSelectedRx(this.orderDetails.displayRx);
      this._appState.setOnHoldReleaseStatus(RELEASE_STATUS.RELEASED);
      this._backEnd.resolveOnHoldOrderIssues(this._appState.getResolveOnHoldPayload(null, RELEASE_STATUS.RELEASED)).subscribe((data) => {
        this._router.navigate([ROUTE_PATHS.CONFIRMATION], {queryParamsHandling: 'merge'});
      }, (error) => {
        this.showServiceError();
      });
    } else {
      this.alert = Object.assign({}, {
        type: ALERT_TYPE.ERROR,
        data: {
          title: Contents.alert.missingInfoHeader,
          link: {
            text: Contents.alert.noPaymentSelected,
            callback: () => {
              const focusable = document.querySelector('.payment-list a, .payment-list input + .custom-radio-button') as HTMLElement;
              focusable && focusable.focus();
            }
          }
        }
      });
    }
  }

  onEditPayment() {    
  }

  cancelOrder() {
    this._modalService.open({
      type: MODAL_TYPE.ORDER_CANCEL,
      data: {
        ...Contents.modal.cancelOrder
      },
      success: (data) => {
        this._appState.setOnHoldReleaseStatus(RELEASE_STATUS.CANCELLED);
        this._backEnd.resolveOnHoldOrderIssues(this._appState.getResolveOnHoldPayload(null, RELEASE_STATUS.CANCELLED)).subscribe(() => {
          this._router.navigate([ROUTE_PATHS.CONFIRMATION], {queryParamsHandling: 'merge'});
        }, (error) => {
          this.showServiceError();
        });
      },
      cancel: (data) => {
      },
      returnFocusTo: '.secondary-btn'
    });
  }

  showServiceError() {
    this.alert = Object.assign({}, {
      type: ALERT_TYPE.ERROR,
      data: {
        ...Contents.alert.onServiceError
      }
    });
  }

  ngOnDestroy(): void {
    this.orderDetails$.unsubscribe();
    this.shippngDetails$.unsubscribe();
  }

}
