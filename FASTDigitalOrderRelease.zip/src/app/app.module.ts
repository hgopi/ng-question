import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { ModalModule } from 'ngx-bootstrap/modal';
import { AppComponent } from './app.component';
import { ConfirmationComponent } from './confirmation/confirmation.component';
import { AppRoutingModule } from './app.routing.module';
import { ConsentPaymentComponent } from './consents/consent-payment/consent-payment.component';
import { EditCardComponent } from './edit-card/edit-card.component';
import { EditBankAccountComponent } from './edit-bank-account/edit-bank-account.component';
import { ConsentShipComponent } from './consents/consent-ship/consent-ship.component';
import { SharedModule } from './shared/shared.module';
import { ConsentRxPaymentComponent } from './consents/consent-rx-payment/consent-rx-payment.component';
import { ConsentsComponent } from './consents/consents.component';
import { ConsentIndefiniteHoldComponent } from './consents/consent-indefinite-hold/consent-indefinite-hold.component';

@NgModule({
  declarations: [
    AppComponent,
    ConfirmationComponent,
    ConsentPaymentComponent,
    EditCardComponent,
    EditBankAccountComponent,
    ConsentShipComponent,
    ConsentRxPaymentComponent,
    ConsentsComponent,
    ConsentIndefiniteHoldComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    AppRoutingModule,
    SharedModule.forRoot(),
    ModalModule.forRoot()
  ],
  providers: [  ],
  bootstrap: [AppComponent],
  entryComponents: [  ]
})
export class AppModule { }
