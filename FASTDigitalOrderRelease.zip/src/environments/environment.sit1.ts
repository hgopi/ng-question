import { Configuration } from '../app/shared/config/config';
import { ENV } from '../app/shared/enum';
import { DeepReadonly } from '../app/shared/type';
import { IEnvironmentConfig } from '../app/shared/models/config';

/**
 * To initialise configuration for 'sit1' environment
 * Initialization can be directly assigned to environment constant,
 * This is Not done because in AOT compilation function calls are restricted inside decorators
 */
Configuration.init(ENV.sit1);

/**
 * Should be readonly to prevent modification
 */
export const environment: DeepReadonly<IEnvironmentConfig> = Configuration.config;
