import React from 'react';
import { Editor, getEventTransfer, getEventRange } from 'slate-react';
import { Block, Value } from 'slate';
import { Button, Icon, Toolbar, Image } from './components/components';
import { isKeyHotkey } from 'is-hotkey';
import initialValue from './value.json';
import isUrl from 'is-url';
import imageExtensions from 'image-extensions';
import Video from './components/video';
import { Table, TableRow, TableCell } from './components/table';
import PluginEditTable from 'slate-edit-table';
import alignPlugin from './components/alignPlugin';

/**
 * Define the default node type.
 */
const DEFAULT_NODE = 'paragraph';

/**
 * Define hotkey matchers.
 */
const isBoldHotkey = isKeyHotkey('mod+b')
const isItalicHotkey = isKeyHotkey('mod+i')
const isUnderlinedHotkey = isKeyHotkey('mod+u')
const isCodeHotkey = isKeyHotkey('mod+`')

/* */
const tablePlugin = PluginEditTable({
  typeTable: 'table',
  typeRow: 'table_row',
  typeCell: 'table_cell',
  typeContent: 'paragraph'
});

/**
 * A change helper to standardize wrapping links.
 */
function wrapLink(change, href) {
  change.wrapInline({
    type: 'link',
    data: { href },
  })

  change.moveToEnd()
}

/**
 * A change helper to standardize unwrapping links.
 */

function unwrapLink(change) {
  change.unwrapInline('link')
}

/*
 * A function to determine whether a URL has an image extension.
 */
function isImage(url) {
  return !!imageExtensions.find(url.endsWith)
}

/**
 * A change function to standardize inserting images.
 */

function insertImage(change, src, target) {
  if (target) {
    change.select(target)
  }

  change.insertBlock({
    type: 'image',
    data: { src },
  })
}

/**
 * A change function to standardize inserting video or embeds.
 */
function insertEmbed(change, src, target) {
  if (target) {
    change.select(target);
  }
  change.insertBlock({
    type: 'video',
    data: { src }
  });
}

/**
 * The editor's schema.
 */

const schema = {
  document: {
    last: { type: 'paragraph' },
    normalize: (change, { code, node, child }) => {
      switch (code) {
        case 'last_child_type_invalid': {
          const paragraph = Block.create('paragraph')
          return change.insertNodeByKey(node.key, node.nodes.size, paragraph)
        }
      }
    },
  },
  blocks: {
    image: {
      isVoid: true,
    },
    video: {
      isVoid: true
    }
  },
}

class NewPost extends React.Component {

  state = {
      value: Value.fromJSON(initialValue)
  };

  /**
   * Check if the current selection has a mark with `type` in it.
   */
  hasMark = type => {
      const { value } = this.state;
      return value.activeMarks.some(mark => mark.type === type);
  }

  /**
   * Check if the any of the currently selected blocks are of `type`.
   */
  hasBlock = type => {
      const { value } = this.state;
      return value.blocks.some(node => node.type === type);
  }

  /**
   * Check whether the current selection has a link in it.
   */
  hasLinks = () => {
    const { value } = this.state
    return value.inlines.some(inline => inline.type == 'link')
  }  

  plugins = [tablePlugin, alignPlugin, { renderNode: this.renderNode }];

  setEditorComponent = (ref) => {
    this.editorREF = ref;
    this.submitChange = ref.change;
  };

  render() {
    return (
      <div className="container">
        <h2>New Post</h2>

        <div className="post-container">
          <Toolbar>
            {this.renderMarkButton('bold', 'format_bold')}
            {this.renderMarkButton('italic', 'format_italic')}
            {this.renderMarkButton('underlined', 'format_underlined')}
            {this.renderMarkButton('code', 'code')}
            <Button active={this.hasLinks()} onMouseDown={this.onClickLink}><Icon>link</Icon></Button>
            <Button onMouseDown={this.onClickImage}><Icon>image</Icon></Button>
            <Button onMouseDown={this.onClickEmbed}><Icon>videocam</Icon></Button>            
            {this.renderBlockButton('heading-one', 'looks_one')}
            {this.renderBlockButton('heading-two', 'looks_two')}
            {this.renderBlockButton('heading-three', 'looks_3')}
            {this.renderBlockButton('heading-four', 'looks_4')}
            {this.renderBlockButton('heading-five', 'looks_5')}
            {this.renderBlockButton('block-quote', 'format_quote')}
            {this.renderBlockButton('numbered-list', 'format_list_numbered')}
            {this.renderBlockButton('bulleted-list', 'format_list_bulleted')}
            <br/><br/>
            <Button onMouseDown={this.onInsertTable}><Icon>table_chart</Icon></Button>
          </Toolbar>

          <Editor
            spellCheck
            autoFocus
            placeholder="Type your post here... "
            schema={schema}
            value={this.state.value}
            onChange={this.onChange}
            onKeyDown={this.onKeyDown}
            renderNode={this.renderNode}
            renderMark={this.renderMark}
            onPaste={this.onPaste}
            onDrop={this.onDrop}
            ref={this.setEditorComponent}
            plugins={this.plugins}/>
        </div>
      </div>
    )
  }


  /**
   * Render a mark-toggling toolbar button.
   */
  renderMarkButton = (type, icon) => {
      const isActive = this.hasMark(type)
  
      return (
        <Button
          active={isActive}
          onMouseDown={event => this.onClickMark(event, type)}>
          <Icon>{icon}</Icon>
        </Button>
      )
  }

  /**
   * Render a block-toggling toolbar button.
   */
  renderBlockButton = (type, icon) => {
      let isActive = this.hasBlock(type)
  
      if (['numbered-list', 'bulleted-list'].includes(type)) {
        const { value } = this.state
        const parent = value.document.getParent(value.blocks.first().key)
        isActive = this.hasBlock('list-item') && parent && parent.type === type
      }
  
      return (
        <Button
          active={isActive}
          onMouseDown={event => this.onClickBlock(event, type)}
        >
          <Icon>{icon}</Icon>
        </Button>
      )
  }

  /**
   * Render a Slate node.
   */
  renderNode = props => {
      const { attributes, children, node, isFocused } = props
  
      switch (node.type) {
        case 'block-quote':
          return <blockquote {...attributes}>{children}</blockquote>
        case 'bulleted-list':
          return <ul {...attributes}>{children}</ul>
        case 'heading-one':
          return <h1 {...attributes}>{children}</h1>
        case 'heading-two':
          return <h2 {...attributes}>{children}</h2>
        case 'heading-three':
          return <h3 {...attributes}>{children}</h3>
        case 'heading-four':
          return <h4 {...attributes}>{children}</h4>
        case 'heading-five':
          return <h5 {...attributes}>{children}</h5>
        case 'list-item':
          return <li {...attributes}>{children}</li>
        case 'numbered-list':
          return <ol {...attributes}>{children}</ol>
        case 'link':
          const { data } = node
          const href = data.get('href')
          return (
            <a {...attributes} href={href}>
              {children}
            </a>
          )
        case 'image':
          const src = node.data.get('src');
          return <Image src={src} selected={isFocused} {...attributes} />
        case 'video':
          return <Video {...props}/>
        case 'table':
          return <Table {...props} />;
        case 'table_row':
          return <TableRow {...props} />;
        case 'table_cell':
          return <TableCell {...props} />;
      }    
  }
  
  /**
   * Render a Slate mark.
   */
  renderMark = props => {
      const { children, mark, attributes } = props
  
      switch (mark.type) {
        case 'bold':
          return <strong {...attributes}>{children}</strong>
        case 'code':
          return <code {...attributes}>{children}</code>
        case 'italic':
          return <em {...attributes}>{children}</em>
        case 'underlined':
          return <u {...attributes}>{children}</u>
      }
  }

  /**
   * On change, save the new `value`.
   */
  onChange = ({ value }) => {
      this.setState({ value })
  }

  /**
   * On key down, if it's a formatting command toggle a mark.
   */
  onKeyDown = (event, change) => {
      let mark
  
      if (isBoldHotkey(event)) {
        mark = 'bold'
      } else if (isItalicHotkey(event)) {
        mark = 'italic'
      } else if (isUnderlinedHotkey(event)) {
        mark = 'underlined'
      } else if (isCodeHotkey(event)) {
        mark = 'code'
      } else {
        return
      }
  
      event.preventDefault()
      change.toggleMark(mark)
      return true
  }

  /**
   * When a mark button is clicked, toggle the current mark.
   */
  onClickMark = (event, type) => {
      event.preventDefault()
      const { value } = this.state
      const change = value.change().toggleMark(type)
      this.onChange(change)
  }    

  /**
   * When a block button is clicked, toggle the block type.
   */
  onClickBlock = (event, type) => {
      event.preventDefault()
      const { value } = this.state
      const change = value.change()
      const { document } = value
  
      // Handle everything but list buttons.
      if (type != 'bulleted-list' && type != 'numbered-list') {
        const isActive = this.hasBlock(type)
        const isList = this.hasBlock('list-item')
  
        if (isList) {
          change
            .setBlocks(isActive ? DEFAULT_NODE : type)
            .unwrapBlock('bulleted-list')
            .unwrapBlock('numbered-list')
        } else {
          change.setBlocks(isActive ? DEFAULT_NODE : type)
        }
      } else {
        // Handle the extra wrapping required for list buttons.
        const isList = this.hasBlock('list-item')
        const isType = value.blocks.some(block => {
          return !!document.getClosest(block.key, parent => parent.type == type)
        })
  
        if (isList && isType) {
          change
            .setBlocks(DEFAULT_NODE)
            .unwrapBlock('bulleted-list')
            .unwrapBlock('numbered-list')
        } else if (isList) {
          change
            .unwrapBlock(
              type === 'bulleted-list' ? 'numbered-list' : 'bulleted-list'
            )
            .wrapBlock(type)
        } else {
          change.setBlocks('list-item').wrapBlock(type)
        }
      }
  
      this.onChange(change)
  }

  /**
   * When clicking a link, if the selection has a link in it, remove the link.
   * Otherwise, add a new link with an href and text.
   */

  onClickLink = event => {
    event.preventDefault()
    const { value } = this.state
    const hasLinks = this.hasLinks()
    const change = value.change()

    if (hasLinks) {
      change.call(unwrapLink)
    } else if (value.isExpanded) {
      const href = window.prompt('Enter the URL of the link:')
      change.call(wrapLink, href)
    } else {
      const href = window.prompt('Enter the URL of the link:')
      const text = window.prompt('Enter the text for the link:')

      change
        .insertText(text)
        .moveFocusTo(0 - text.length)
        .call(wrapLink, href)
    }

    this.onChange(change)
  }

  /**
   * On paste, if the text is a link, wrap the selection in a link.
   */
  onPaste = (event, change) => {
    if (change.value.selection.isCollapsed) return

    const transfer = getEventTransfer(event)
    const { type, text } = transfer
    if (type !== 'text' && type !== 'html') return
    if (!isUrl(text)) return

    if (this.hasLinks()) {
      change.call(unwrapLink)
    }

    change.call(wrapLink, text)
    return true
  }

  /**
   * On clicking the image button, prompt for an image and insert it.
   */
  onClickImage = event => {
    event.preventDefault()
    const src = window.prompt('Enter the URL of the image:')
    if (!src) return

    const change = this.state.value.change().call(insertImage, src)

    this.onChange(change)
  }

  onClickEmbed = event => {
    event.preventDefault();
    const src = window.prompt('Enter the URL of the embed:');
    if (!src) return;
    const change = this.state.value.change().call(insertEmbed, src);
    this.onChange(change);
  }

  onDrop = (event, change, editor) => {
    const target = getEventRange(event, change.value)
    if (!target && event.type == 'drop') return

    const transfer = getEventTransfer(event)
    const { type, text, files } = transfer

    if (type == 'files') {
      for (const file of files) {
        const reader = new FileReader()
        const [mime] = file.type.split('/')
        if (mime != 'image') continue

        reader.addEventListener('load', () => {
          editor.change(c => {
            c.call(insertImage, reader.result, target)
          })
        })

        reader.readAsDataURL(file)
      }
    }

    if (type == 'text') {
      if (!isUrl(text)) return
      if (!isImage(text)) return
      change.call(insertImage, text, target)
    }
  }
  

  onInsertTable = event => {
    event.preventDefault();
    this.submitChange(tablePlugin.changes.insertTable);
  };

}

export default NewPost;

// https://github.com/GitbookIO/slate-edit-table/blob/master/example/main.js
// https://gitbookio.github.io/slate-edit-table/